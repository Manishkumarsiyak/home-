# Digital Guardian Android APK Project
This is the complete native Android project source for the Digital Guardian application.

## How to build APK:
1. Open this folder in Android Studio.
2. Click Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The generated APK will be in:
   app/build/outputs/apk/debug/app-debug.apk

Or in terminal:
./gradlew assembleDebug
