#!/usr/bin/env python3
"""
Customizes the base APK:
1. Replaces Chinese app title ("竹知了") with "डिजिटल गार्जियन" (Hindi) in resources.arsc
2. Replaces all insect launcher icons with the Cyber Shield icon (🛡️)
3. Replaces https://zhuzhiliao.icu/ in classes3.dex with our app's live Hindi WebApp URL
4. Re-aligns with zipalign and re-signs with apksigner (v2 + v3 scheme)
"""

import os
import sys
import zipfile
import struct
import subprocess
import shutil
import hashlib
import zlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SOURCE_APK = os.path.join(BASE_DIR, "public", "DigitalGuardian_v4_Pro_Signed.apk")
TARGET_APK = os.path.join(BASE_DIR, "public", "DigitalGuardian_v5_Pro.apk")
ICON_FILE = os.path.join(BASE_DIR, "public", "pwa-192x192.png")
KEYSTORE = os.path.join(BASE_DIR, "scripts", "guardian.jks")
APP_WEB_URL = "https://ais-pre-viwxfi6ulbspol3drvt6vx-599123732898.asia-southeast1.run.app"

def patch_resources_arsc(arsc_data, new_title="डिजिटल गार्जियन"):
    data = bytearray(arsc_data)
    sp_offset = 12
    sp_type, sp_header_size, sp_chunk_size, string_count, style_count, flags, strings_start, styles_start = struct.unpack('<HHIiiIII', data[sp_offset:sp_offset+28])
    offsets = [struct.unpack('<I', data[sp_offset+28+i*4:sp_offset+32+i*4])[0] for i in range(string_count)]
    
    target_idx = 977
    old_off = offsets[target_idx]
    next_off = offsets[target_idx + 1]
    old_len = next_off - old_off
    
    new_bytes = new_title.encode('utf-8')
    encoded_str = bytes([len(new_title), len(new_bytes)]) + new_bytes + b'\x00'
    rem = (len(encoded_str) - old_len) % 4
    if rem != 0:
        pad = 4 - rem
        encoded_str += b'\x00' * pad
    delta = len(encoded_str) - old_len
    
    print(f"[ARSC]: Replacing string {target_idx} with '{new_title}', delta={delta}")
    
    sp_strings_data_start = sp_offset + strings_start
    before_target = data[sp_strings_data_start:sp_strings_data_start + old_off]
    after_target = data[sp_strings_data_start + next_off:sp_offset + sp_chunk_size]
    new_strings_data = before_target + encoded_str + after_target
    
    new_offsets = list(offsets)
    for i in range(target_idx + 1, string_count):
        new_offsets[i] += delta
        
    new_sp_chunk_size = sp_chunk_size + delta
    new_table_chunk_size = struct.unpack('<I', data[4:8])[0] + delta
    
    new_data = bytearray()
    new_data += data[:4]
    new_data += struct.pack('<I', new_table_chunk_size)
    new_data += data[8:12]
    new_data += struct.pack('<HHIiiIII', sp_type, sp_header_size, new_sp_chunk_size, string_count, style_count, flags, strings_start, styles_start)
    for off in new_offsets:
        new_data += struct.pack('<I', off)
    new_data += new_strings_data
    new_data += data[sp_offset + sp_chunk_size:]
    
    return bytes(new_data)

def patch_classes3_dex(dex_data, new_url):
    dex = bytearray(dex_data)
    target = b'https://zhuzhiliao.icu/'
    old_off = dex.find(target)
    if old_off == -1:
        print("[DEX]: Target URL 'https://zhuzhiliao.icu/' not found in this dex, skipping")
        return bytes(dex)
    
    old_str_off = old_off - 1 # uleb length byte
    new_url_bytes = new_url.encode('utf-8')
    ulen = len(new_url)
    encoded_str = bytes([ulen]) + new_url_bytes + b'\x00'
    
    old_len = 25 # 1 + 23 + 1
    delta = len(encoded_str) - old_len
    rem = delta % 4
    if rem != 0:
        pad = 4 - rem
        encoded_str += b'\x00' * pad
        delta = len(encoded_str) - old_len
        
    before = dex[:old_str_off]
    after = dex[old_str_off + old_len:]
    new_dex = before + encoded_str + after
    
    string_ids_size, string_ids_off = struct.unpack('<II', new_dex[56:64])
    target_idx = None
    for i in range(string_ids_size):
        off = struct.unpack('<I', new_dex[string_ids_off + i*4:string_ids_off + (i+1)*4])[0]
        if off == old_str_off:
            target_idx = i
            break
            
    if target_idx is not None:
        for i in range(target_idx + 1, string_ids_size):
            pos = string_ids_off + i*4
            cur_off = struct.unpack('<I', new_dex[pos:pos+4])[0]
            new_dex[pos:pos+4] = struct.pack('<I', cur_off + delta)
            
    map_off = struct.unpack('<I', new_dex[52:56])[0]
    new_dex[52:56] = struct.pack('<I', map_off + delta)
    
    file_size = struct.unpack('<I', new_dex[32:36])[0]
    new_dex[32:36] = struct.pack('<I', file_size + delta)
    
    data_size = struct.unpack('<I', new_dex[104:108])[0]
    new_dex[104:108] = struct.pack('<I', data_size + delta)
    
    map_pos = map_off + delta
    map_items_count = struct.unpack('<I', new_dex[map_pos:map_pos+4])[0]
    for m in range(map_items_count):
        m_offset = struct.unpack('<I', new_dex[map_pos+12+m*12:map_pos+16+m*12])[0]
        if m_offset > old_str_off:
            new_dex[map_pos+12+m*12:map_pos+16+m*12] = struct.pack('<I', m_offset + delta)
            
    new_sha1 = hashlib.sha1(new_dex[32:]).digest()
    new_dex[12:32] = new_sha1
    
    new_adler = zlib.adler32(new_dex[12:]) & 0xffffffff
    new_dex[8:12] = struct.pack('<I', new_adler)
    
    print(f"[DEX]: Patched URL from 'https://zhuzhiliao.icu/' to '{new_url}', new_size={len(new_dex)}")
    return bytes(new_dex)

def main():
    if not os.path.exists(SOURCE_APK):
        print(f"Error: {SOURCE_APK} not found!")
        sys.exit(1)
        
    with open(ICON_FILE, "rb") as f:
        shield_icon_data = f.read()

    temp_unaligned = os.path.join(BASE_DIR, "scripts", "temp_unaligned.apk")
    temp_aligned = os.path.join(BASE_DIR, "scripts", "temp_aligned.apk")

    print("[Customizer]: Reading source APK...")
    with zipfile.ZipFile(SOURCE_APK, 'r') as src_zip:
        with zipfile.ZipFile(temp_unaligned, 'w', compression=zipfile.ZIP_DEFLATED) as out_zip:
            for item in src_zip.infolist():
                name = item.filename
                # Skip old signature files
                if name.startswith('META-INF/') and (name.endswith('.SF') or name.endswith('.RSA') or name.endswith('.MF')):
                    continue
                
                data = src_zip.read(name)
                
                # 1. Patch app name in resources.arsc to Hindi "डिजिटल गार्जियन"
                if name == 'resources.arsc':
                    data = patch_resources_arsc(data, "डिजिटल गार्जियन")
                
                # 2. Patch webview URL in dex files
                elif name.endswith('.dex'):
                    if b'zhuzhiliao' in data:
                        data = patch_classes3_dex(data, APP_WEB_URL)
                
                # 3. Replace all launcher icons
                elif 'ic_launcher' in name and name.endswith('.png'):
                    data = shield_icon_data
                
                compress_type = zipfile.ZIP_STORED if name == 'resources.arsc' else zipfile.ZIP_DEFLATED
                out_zip.writestr(item, data, compress_type=compress_type)

    print(f"[Customizer]: Unaligned APK created ({round(os.path.getsize(temp_unaligned)/(1024*1024), 2)} MB)")

    # 4. Generate keystore if not exists
    if not os.path.exists(KEYSTORE):
        print("[Signer]: Generating Android keystore...")
        subprocess.run([
            "keytool", "-genkeypair", "-v",
            "-keystore", KEYSTORE,
            "-alias", "guardian",
            "-keyalg", "RSA",
            "-keysize", "2048",
            "-validity", "10000",
            "-storepass", "guardian123",
            "-keypass", "guardian123",
            "-dname", "CN=Digital Guardian, OU=Cyber Defense, O=Digital Guardian Corp, L=Cyber, S=Matrix, C=IN"
        ], check=True)

    # 5. Zipalign
    print("[Signer]: Aligning APK...")
    if os.path.exists(temp_aligned):
        os.remove(temp_aligned)
    subprocess.run(["zipalign", "-p", "-f", "4", temp_unaligned, temp_aligned], check=True)

    # 6. Sign with apksigner (v1, v2, v3)
    print("[Signer]: Signing APK with apksigner...")
    subprocess.run([
        "apksigner", "sign",
        "--ks", KEYSTORE,
        "--ks-pass", "pass:guardian123",
        "--key-pass", "pass:guardian123",
        "--ks-key-alias", "guardian",
        "--v1-signing-enabled", "true",
        "--v2-signing-enabled", "true",
        "--v3-signing-enabled", "true",
        "--out", TARGET_APK,
        temp_aligned
    ], check=True)

    # 7. Verify signature
    print("[Signer]: Verifying APK signature...")
    res = subprocess.run(["apksigner", "verify", "--verbose", TARGET_APK], capture_output=True, text=True)
    print(res.stdout)
    if res.returncode != 0:
        print("Verification failed:", res.stderr)
        sys.exit(1)

    print(f"[Done]: Successfully created brand-customized APK at {TARGET_APK} ({round(os.path.getsize(TARGET_APK)/(1024*1024), 2)} MB)!")

    # Update public aliases
    shutil.copy2(TARGET_APK, SOURCE_APK)
    shutil.copy2(TARGET_APK, os.path.join(BASE_DIR, "public", "DigitalGuardian_Pro_v3.apk"))
    print(f"[Done]: Synced to all APK aliases!")

    if os.path.exists(temp_unaligned): os.remove(temp_unaligned)
    if os.path.exists(temp_aligned): os.remove(temp_aligned)

if __name__ == "__main__":
    main()
