import os
import zipfile

base_dir = 'android-project'
os.makedirs(f'{base_dir}/app/src/main/java/com/digitalguardian/core', exist_ok=True)
os.makedirs(f'{base_dir}/app/src/main/res/values', exist_ok=True)

manifest = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.digitalguardian.core">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.BATTERY_STATS" />

    <application
        android:allowBackup="true"
        android:label="Digital Guardian"
        android:icon="@mipmap/ic_launcher"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>"""

with open(f'{base_dir}/app/src/main/AndroidManifest.xml', 'w', encoding='utf-8') as f:
    f.write(manifest)

main_activity = """package com.digitalguardian.core

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Loads the Digital Guardian Applet URL
        val appUrl = "https://ais-dev-viwxfi6ulbspol3drvt6vx-599123732898.asia-southeast1.run.app"
        webView.loadUrl(appUrl)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}"""

with open(f'{base_dir}/app/src/main/java/com/digitalguardian/core/MainActivity.kt', 'w', encoding='utf-8') as f:
    f.write(main_activity)

app_gradle = """plugins {
    id 'com.android.application'
    id 'kotlin-android'
}

android {
    namespace 'com.digitalguardian.core'
    compileSdk 34

    defaultConfig {
        applicationId "com.digitalguardian.core"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
}"""

with open(f'{base_dir}/app/build.gradle', 'w', encoding='utf-8') as f:
    f.write(app_gradle)

readme = """# Digital Guardian Android APK Project
This is the complete native Android project source for the Digital Guardian application.

## How to build APK:
1. Open this folder in Android Studio.
2. Click Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The generated APK will be in:
   app/build/outputs/apk/debug/app-debug.apk

Or in terminal:
./gradlew assembleDebug
"""

with open(f'{base_dir}/README.md', 'w', encoding='utf-8') as f:
    f.write(readme)

# Package into zip
os.makedirs('public', exist_ok=True)
zip_name = 'public/DigitalGuardian_Android_Source.zip'
with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, base_dir)
            zipf.write(file_path, arcname)

print(f"Android Project ZIP generated successfully: {os.path.getsize(zip_name)} bytes")
