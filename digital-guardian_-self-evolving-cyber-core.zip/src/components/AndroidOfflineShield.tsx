import React, { useState, useEffect } from 'react';
import { WifiOff, RefreshCw, ShieldCheck, Smartphone } from 'lucide-react';
import { triggerHaptic } from '../utils/audio';

interface AndroidOfflineShieldProps {
  language: 'hi' | 'en' | 'dual';
}

export const AndroidOfflineShield: React.FC<AndroidOfflineShieldProps> = ({ language }) => {
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isChecking, setIsChecking] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => {
      setIsOnline(false);
      triggerHaptic('warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleRetry = async () => {
    setIsChecking(true);
    triggerHaptic('light');
    try {
      const res = await fetch('/api/guardian/status', { method: 'HEAD', cache: 'no-store' });
      if (res.ok) {
        setIsOnline(true);
        triggerHaptic('success');
      }
    } catch {
      setIsOnline(false);
      triggerHaptic('warning');
    } finally {
      setIsChecking(false);
    }
  };

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-amber-500/95 text-slate-950 px-4 py-2 text-xs font-mono font-bold shadow-lg flex items-center justify-between gap-3 animate-in slide-in-from-top backdrop-blur">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0 animate-pulse text-slate-950" />
        <span>
          {language === 'hi'
            ? 'ऑफलाइन मोड: इंटरनेट बंद है, लेकिन स्थानीय शील्ड सक्रिय है!'
            : 'Offline Mode: Network disconnected. Local shield active!'}
        </span>
      </div>
      <button
        onClick={handleRetry}
        disabled={isChecking}
        className="px-2.5 py-1 rounded bg-slate-950 text-amber-300 hover:bg-slate-900 text-[11px] font-bold flex items-center gap-1 shrink-0 active:scale-95 transition-all"
      >
        <RefreshCw className={`w-3 h-3 ${isChecking ? 'animate-spin' : ''}`} />
        <span>{language === 'hi' ? 'रीकनेक्ट' : 'Retry'}</span>
      </button>
    </div>
  );
};
