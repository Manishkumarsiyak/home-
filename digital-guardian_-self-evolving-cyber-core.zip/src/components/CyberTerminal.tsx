import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal, 
  Trash2, 
  CornerDownLeft, 
  Radio, 
  ShieldCheck, 
  Sparkles,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { TerminalLog, GuardianStatus } from '../types';

interface CyberTerminalProps {
  logs: TerminalLog[];
  status: GuardianStatus | null;
  onCommand: (cmd: string) => void;
  onClear: () => void;
  language: 'hi' | 'en' | 'dual';
}

export const CyberTerminal: React.FC<CyberTerminalProps> = ({
  logs,
  status,
  onCommand,
  onClear,
  language
}) => {
  const [inputVal, setInputVal] = useState('');
  const [filter, setFilter] = useState<'all' | 'guardian' | 'system' | 'alerts'>('all');
  const [expanded, setExpanded] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    onCommand(inputVal.trim());
    setInputVal('');
  };

  const filteredLogs = logs.filter(log => {
    if (filter === 'guardian') return log.type === 'guardian' || log.type === 'success';
    if (filter === 'system') return log.type === 'system' || log.type === 'info';
    if (filter === 'alerts') return log.type === 'warning' || log.type === 'error';
    return true;
  });

  return (
    <div className={`rounded-2xl border border-slate-800 bg-slate-950/95 overflow-hidden shadow-2xl flex flex-col font-mono ${
      expanded ? 'fixed inset-4 z-50' : 'h-[600px]'
    }`}>
      {/* Terminal Title Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
          </div>
          <span className="text-slate-600">|</span>
          <span className="font-bold text-emerald-400 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5" />
            GUARDIAN LIVE TTY // TERMINAL
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-900">
            TTY: /dev/pts/0
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Filters */}
          <div className="flex rounded-lg border border-slate-800 bg-slate-950 p-0.5 text-[11px]">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-0.5 rounded ${filter === 'all' ? 'bg-slate-800 text-emerald-300 font-bold' : 'text-slate-400'}`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('guardian')}
              className={`px-2 py-0.5 rounded ${filter === 'guardian' ? 'bg-slate-800 text-emerald-300 font-bold' : 'text-slate-400'}`}
            >
              Guardian
            </button>
            <button
              onClick={() => setFilter('alerts')}
              className={`px-2 py-0.5 rounded ${filter === 'alerts' ? 'bg-slate-800 text-emerald-300 font-bold' : 'text-slate-400'}`}
            >
              Alerts
            </button>
          </div>

          <button
            onClick={onClear}
            className="p-1 rounded text-slate-500 hover:text-slate-200 transition-colors"
            title="Clear Terminal"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1 rounded text-slate-500 hover:text-slate-200 transition-colors"
            title={expanded ? "Minimize Terminal" : "Maximize Terminal"}
          >
            {expanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Terminal Output Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-2 text-xs leading-relaxed cyber-scanline">
        {filteredLogs.map((log, index) => {
          let colorClass = 'text-slate-300';
          let prefix = '[SYS]';

          if (log.type === 'guardian') {
            colorClass = 'text-emerald-300 font-medium';
            prefix = '[GUARDIAN]';
          } else if (log.type === 'success') {
            colorClass = 'text-teal-300 font-bold';
            prefix = '[ASCENDED]';
          } else if (log.type === 'warning') {
            colorClass = 'text-amber-300';
            prefix = '[FALLBACK]';
          } else if (log.type === 'error') {
            colorClass = 'text-rose-400 font-bold';
            prefix = '[ERROR]';
          } else if (log.type === 'info') {
            colorClass = 'text-cyan-300';
            prefix = '[TELEMETRY]';
          }

          return (
            <div key={index} className="flex items-start gap-2 group hover:bg-slate-900/30 px-1 py-0.5 rounded">
              <span className="text-slate-600 select-none text-[10px] w-16 shrink-0">{log.timestamp}</span>
              <span className="text-slate-500 select-none text-[10px] font-bold shrink-0">{prefix}</span>
              <span className={`${colorClass} break-all whitespace-pre-wrap`}>{log.text}</span>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Terminal Input Line */}
      <form onSubmit={handleSubmit} className="border-t border-slate-800 bg-slate-900/80 px-4 py-2.5 flex items-center gap-3">
        <span className="text-emerald-400 font-bold text-xs select-none flex items-center gap-1">
          <span>guardian@core</span>
          <span className="text-slate-500">:</span>
          <span className="text-cyan-400">~</span>
          <span>$</span>
        </span>
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder={language === 'hi' ? "कमांड टाइप करें: 'help', 'status', 'evolve', 'health', 'clear'..." : "Enter command: 'help', 'status', 'evolve', 'health', 'clear'..."}
          className="flex-1 bg-transparent text-xs text-slate-100 placeholder-slate-600 focus:outline-none font-mono"
        />
        <button
          type="submit"
          className="p-1 rounded text-slate-400 hover:text-emerald-400 transition-colors"
        >
          <CornerDownLeft className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
