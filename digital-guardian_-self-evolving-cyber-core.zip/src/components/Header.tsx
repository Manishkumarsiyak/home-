import React from 'react';
import { 
  Shield, 
  Cpu, 
  Terminal, 
  Zap, 
  Download, 
  Volume2, 
  VolumeX, 
  RefreshCw,
  Sparkles,
  Layers,
  Smartphone,
  Radar
} from 'lucide-react';
import { GuardianStatus } from '../types';

interface HeaderProps {
  status: GuardianStatus | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isEvolving: boolean;
  onTriggerEvolve: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  language: 'hi' | 'en' | 'dual';
  setLanguage: (lang: 'hi' | 'en' | 'dual') => void;
  onOpenAndroidSettings?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  activeTab,
  setActiveTab,
  isEvolving,
  onTriggerEvolve,
  soundEnabled,
  setSoundEnabled,
  language,
  setLanguage,
  onOpenAndroidSettings
}) => {
  const level = status?.level ?? 1;
  const rank = status?.rank ?? 'Sentinel Core // Phase 1';

  return (
    <header className="border-b border-emerald-950/60 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Top Cyber Ticker */}
      <div className="bg-emerald-950/30 border-b border-emerald-900/30 px-4 py-1 text-xs text-emerald-400/80 font-mono flex items-center justify-between overflow-x-auto gap-4">
        <div className="flex items-center gap-3 shrink-0">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            {language === 'hi' ? '🟢 सुरक्षा प्रणाली सक्रिय है' : 'DEFENSE CORE ACTIVE'}
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">
            {language === 'hi' ? 'AI सुरक्षा इंजन: ' : 'AI ENGINE: '}
            <strong className="text-amber-400">Groq (Llama 3.3)</strong> + <strong className="text-cyan-400">Gemini 3.8 Flash</strong>
          </span>
        </div>
        <div className="flex items-center gap-3 text-slate-400 shrink-0">
          <span>{language === 'hi' ? 'सुरक्षा स्कोर: ' : 'INTEGRITY: '}<strong className="text-emerald-400 font-bold">{status?.resilienceScore || 88}%</strong></span>
          <span className="text-slate-600">|</span>
          <span>{language === 'hi' ? 'लेवल: ' : 'LEVEL: '}<strong className="text-cyan-300 font-bold">Lvl {level}</strong></span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-4">
        {/* Logo and Level */}
        <div className="flex items-center gap-3">
          <div className="relative p-2.5 rounded-xl bg-gradient-to-br from-emerald-950/80 to-slate-900 border border-emerald-500/30 shadow-lg shadow-emerald-950/50">
            <Shield className="w-7 h-7 text-emerald-400 animate-pulse" />
            <div className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500 text-slate-950">
              v{level}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-wider font-cyber bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-400 bg-clip-text text-transparent">
                {language === 'hi' ? 'डिजिटल गार्जियन PRO' : 'DIGITAL GUARDIAN PRO'}
              </h1>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded border border-emerald-500/30 bg-emerald-950/40 text-emerald-300">
                {language === 'hi' ? `लेवल ${level}` : `Lvl ${level}`}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono flex items-center gap-2">
              <span className="text-emerald-400 font-semibold">{language === 'hi' ? '24/7 सक्रिय सुरक्षा ढाल' : rank}</span>
              <span className="text-slate-600">•</span>
              <span>{language === 'hi' ? '100% शुद्ध हिंदी सुरक्षा ऐप' : 'Autonomous Cyber-Evolution Core'}</span>
            </p>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language selector */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/60 p-0.5 text-xs font-mono">
            <button
              onClick={() => setLanguage('dual')}
              className={`px-2 py-1 rounded transition-all ${
                language === 'dual' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Dual Hindi & English"
            >
              हिं/EN
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2 py-1 rounded transition-all ${
                language === 'hi' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Hindi Mode"
            >
              हिंदी
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 rounded transition-all ${
                language === 'en' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="English Mode"
            >
              ENG
            </button>
          </div>

          {/* Sound toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-lg border border-slate-800 bg-slate-900/60 text-slate-400 hover:text-emerald-300 transition-colors"
            title={soundEnabled ? "Mute Cyber Audio FX" : "Enable Cyber Audio FX"}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Android Optimization Settings Button */}
          {onOpenAndroidSettings && (
            <button
              onClick={onOpenAndroidSettings}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-emerald-500/40 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/60 transition-colors shadow-sm"
              title={language === 'hi' ? 'एंड्रॉइड बैकग्राउंड सेटिंग्स' : 'Android Background Settings'}
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">{language === 'hi' ? 'फ़ोन सेटिंग्स' : 'Android Opt'}</span>
            </button>
          )}

          {/* Download APK Quick Action */}
          <a
            href="/api/guardian/download-apk?v=5"
            download="DigitalGuardian_v5_Pro_Signed.apk"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/60 transition-colors shadow-sm"
            title="Download Standalone Android APK (6.2 MB)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Get .APK (6.2 MB)</span>
          </a>

          {/* Evolution Button */}
          <button
            onClick={onTriggerEvolve}
            disabled={isEvolving}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-bold font-cyber tracking-wider rounded-lg border shadow-lg transition-all ${
              isEvolving
                ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-300 cursor-not-allowed animate-pulse'
                : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 border-emerald-400/50 text-slate-950 hover:from-emerald-500 hover:to-teal-400 shadow-emerald-500/20 hover:scale-[1.02] active:scale-[0.98]'
            }`}
          >
            {isEvolving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                <span>{language === 'hi' ? 'विकास जारी है...' : 'EVOLVING...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{language === 'hi' ? 'नया विकास ट्रिगर करें' : 'EVOLVE CORE'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-1 sm:gap-2 overflow-x-auto border-t border-slate-800/60 py-1.5 font-mono text-xs no-scrollbar">
        {[
          { id: 'apk', label: language === 'hi' ? '📱 मोबाइल APK डाउनलोड' : 'APK Hub & Download', icon: Smartphone, badge: language === 'hi' ? 'सीधा इंस्टॉल' : '.APK' },
          { id: 'chat', label: language === 'hi' ? '🤖 सुरक्षा सहायक (AI चैट)' : 'AI Guardian Chat', icon: Zap, badge: 'AI' },
          { id: 'deck', label: language === 'hi' ? '🛡️ सुरक्षा कंट्रोल रूम' : 'Command Deck', icon: Layers },
          { id: 'radar', label: language === 'hi' ? '📡 वायरस और हैकर रडार' : 'Threat Radar', icon: Radar },
          { id: 'powers', label: language === 'hi' ? '🔐 फोन सुरक्षा अनुमतियाँ' : 'Device Permissions', icon: Shield },
          { id: 'quantum', label: language === 'hi' ? '⚡ 1000X पावर बूस्ट' : '1000X Quantum Core', icon: Cpu, badge: '1000X' },
          { id: 'lab', label: language === 'hi' ? '🧬 ऑटो-अपग्रेड लैब' : 'Evolution Lab', icon: Zap },
          { id: 'vault', label: language === 'hi' ? '💾 सुरक्षित बैकअप वॉल्ट' : 'Backup Vault', icon: RefreshCw },
          { id: 'terminal', label: language === 'hi' ? '📋 सुरक्षा लॉग्स' : 'Terminal Logs', icon: Terminal },
          { id: 'python', label: language === 'hi' ? '💻 सुरक्षा कोड' : 'Python Script', icon: Layers }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold shadow-sm shadow-emerald-950'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40 border border-transparent'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                  isActive ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
