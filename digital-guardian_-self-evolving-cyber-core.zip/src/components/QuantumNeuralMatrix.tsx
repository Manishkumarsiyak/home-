import React, { useState, useEffect, useRef } from 'react';
import { 
  Cpu, 
  Lock, 
  Unlock, 
  Key, 
  Globe, 
  ShieldAlert, 
  CheckCircle, 
  Zap, 
  Activity, 
  Layers, 
  RefreshCw, 
  Hash, 
  Terminal,
  Database
} from 'lucide-react';
import { CipherResult, ThreatNode } from '../types';
import { playCyberSound } from '../utils/audio';

interface QuantumNeuralMatrixProps {
  language: 'hi' | 'en' | 'dual';
  soundEnabled: boolean;
  level: number;
}

export const QuantumNeuralMatrix: React.FC<QuantumNeuralMatrixProps> = ({
  language,
  soundEnabled,
  level
}) => {
  // Cipher Testbench state
  const [plainInput, setPlainInput] = useState('DIGITAL_GUARDIAN_LEVEL_1000X_PAYLOAD');
  const [secretKey, setSecretKey] = useState('QUANTUM_CIPHER_CORE_2026');
  const [cipherResult, setCipherResult] = useState<CipherResult | null>(null);
  const [isCiphering, setIsCiphering] = useState(false);
  const [cipherMode, setCipherMode] = useState<'encrypt' | 'decrypt'>('encrypt');

  // Threat Matrix telemetry
  const [nodes, setNodes] = useState<ThreatNode[]>([]);
  const [totalIntercepts, setTotalIntercepts] = useState(384);
  const [synapseFreq, setSynapseFreq] = useState(5.2);
  const [loadingTelemetry, setLoadingTelemetry] = useState(false);

  // Canvas ref for Neural Synapses Animation
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Fetch Threat Matrix
  const fetchThreatMatrix = async () => {
    try {
      const res = await fetch('/api/guardian/threat-matrix');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setNodes(data.globalNodes || []);
          setTotalIntercepts(data.totalThreatsNeutralized || 384);
          setSynapseFreq(data.synapseFrequencyGhz || 5.2);
        }
      }
    } catch {}
  };

  useEffect(() => {
    fetchThreatMatrix();
    const interval = setInterval(fetchThreatMatrix, 12000);
    return () => clearInterval(interval);
  }, []);

  // Neural Synapses Canvas Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const particles: Array<{ x: number; y: number; vx: number; vy: number; radius: number; color: string }> = [];
    const colors = ['#10b981', '#06b6d4', '#14b8a6', '#38bdf8'];

    for (let i = 0; i < 35; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2 + 1.5,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 90) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(16, 185, 129, ${0.25 * (1 - dist / 90)})`;
            ctx.lineWidth = 0.8;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw and move particles
      for (let p of particles) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  // Execute Real AES-256 GCM Cipher
  const handleRunCipher = async () => {
    setIsCiphering(true);
    playCyberSound('click', soundEnabled);

    try {
      const payload: any = {
        action: cipherMode,
        secretKey
      };

      if (cipherMode === 'encrypt') {
        payload.text = plainInput;
      } else {
        payload.ciphertext = cipherResult?.ciphertext || plainInput;
        payload.iv = cipherResult?.iv;
        payload.authTag = cipherResult?.authTag;
      }

      const res = await fetch('/api/guardian/quantum-cipher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playCyberSound('success', soundEnabled);
        setCipherResult(data);
      } else {
        playCyberSound('warning', soundEnabled);
        alert(`Cipher error: ${data.error || 'Operation failed'}`);
      }
    } catch (err: any) {
      playCyberSound('warning', soundEnabled);
    } finally {
      setIsCiphering(false);
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Top Holographic Matrix Banner */}
      <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 p-6 shadow-2xl relative overflow-hidden">
        {/* Background Neural Synapses Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
        />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold font-cyber bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>1000X QUANTUM NEURAL CORE</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold font-cyber text-slate-100">
              Autonomous Quantum Cryptography & Global Honeypot Mesh
            </h2>

            <p className="text-xs text-slate-300 leading-relaxed">
              {language === 'hi'
                ? 'यह 1000x उन्नत न्यूरल कोर वास्तविक समय में सैन्य-ग्रेड AES-256-GCM सिफर, SHA-512 ऑथेंटिकेशन टैग्स, और विश्व भर के 8 सक्रिय हनीपॉट नोड्स से साइबर खतरों को इंटरसेप्ट करता है।'
                : '1000X Neural Synapse Core executing real-time AES-256 GCM memory obfuscation, SHA-512 integrity verification, and global distributed canary honeypot interception.'}
            </p>
          </div>

          {/* Core Telemetry Gauges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
            <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/40 text-center">
              <div className="text-[10px] text-slate-400">SYNAPSE FREQ</div>
              <div className="text-lg font-bold font-cyber text-emerald-400">{synapseFreq.toFixed(1)} GHz</div>
              <div className="text-[9px] text-emerald-500/80">OVERCLOCKED</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/80 border border-cyan-500/40 text-center">
              <div className="text-[10px] text-slate-400">THREATS INTERCEPTED</div>
              <div className="text-lg font-bold font-cyber text-cyan-400">{totalIntercepts}</div>
              <div className="text-[9px] text-cyan-500/80">GLOBAL MESH</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/80 border border-amber-500/40 text-center col-span-2 sm:col-span-1">
              <div className="text-[10px] text-slate-400">CIPHER PROTOCOL</div>
              <div className="text-lg font-bold font-cyber text-amber-400">AES-256</div>
              <div className="text-[9px] text-amber-500/80">GCM AUTHENTICATED</div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive AES-256 GCM Quantum Cipher Workbench */}
      <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/60 p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold font-cyber text-slate-100">
                AES-256 GCM Live Quantum Encryption Testbench
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'hi' ? 'वास्तविक क्रिप्टोग्राफिक एन्क्रिप्शन और डिक्रिप्शन का लाइव परीक्षण करें' : 'Test real node.js crypto military-grade payload encryption in real-time'}
              </p>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-950 p-1 text-xs">
            <button
              onClick={() => setCipherMode('encrypt')}
              className={`px-3 py-1 rounded transition-all ${
                cipherMode === 'encrypt'
                  ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ENCRYPT (ताला लगाएँ)
            </button>
            <button
              onClick={() => setCipherMode('decrypt')}
              className={`px-3 py-1 rounded transition-all ${
                cipherMode === 'decrypt'
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              DECRYPT (ताला खोलें)
            </button>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="space-y-1.5">
            <label className="text-slate-400 flex items-center justify-between">
              <span>{cipherMode === 'encrypt' ? 'Plaintext Payload (डेटा):' : 'Encrypted Ciphertext (Hex):'}</span>
              <span className="text-[10px] text-slate-500">UTF-8 / HEX</span>
            </label>
            <input
              type="text"
              value={plainInput}
              onChange={(e) => setPlainInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500/60"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-slate-400 flex items-center justify-between">
              <span>Secret Cryptographic Key (सीक्रेट कुंजी):</span>
              <span className="text-[10px] text-emerald-400">SHA-256 Derived</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500/60 font-mono"
              />
              <Key className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-3" />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end">
          <button
            onClick={handleRunCipher}
            disabled={isCiphering || !plainInput}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold font-cyber text-xs bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
          >
            {cipherMode === 'encrypt' ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>
              {isCiphering ? 'PROCESSING...' : cipherMode === 'encrypt' ? 'EXECUTE AES-256 ENCRYPT' : 'EXECUTE AES-256 DECRYPT'}
            </span>
          </button>
        </div>

        {/* Cipher Results Display */}
        {cipherResult && (
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-3 text-xs animate-in fade-in">
            <div className="flex items-center justify-between text-[11px] pb-2 border-b border-slate-800/80">
              <span className="text-emerald-400 font-bold font-cyber flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>CRYPTOGRAPHIC OPERATION SUCCESSFUL</span>
              </span>
              <span className="text-slate-500">Latency: {cipherResult.executionTimeMs || 1.2}ms</span>
            </div>

            {cipherResult.action === 'encrypt' ? (
              <div className="space-y-2">
                <div>
                  <div className="text-[10px] text-slate-400 mb-1">Encrypted Ciphertext (Hex):</div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 font-mono break-all text-[11px]">
                    {cipherResult.ciphertext}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                  <div>
                    <span className="text-slate-400">IV (Initialization Vector): </span>
                    <span className="text-amber-300 font-mono">{cipherResult.iv}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">GCM Auth Tag: </span>
                    <span className="text-emerald-400 font-mono">{cipherResult.authTag}</span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400">SHA-512 Seal Hash: </span>
                  <span className="text-purple-300 font-mono break-all">{cipherResult.integrityHash}</span>
                </div>
              </div>
            ) : (
              <div>
                <div className="text-[10px] text-slate-400 mb-1">Decrypted Plaintext:</div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-emerald-500/40 text-emerald-300 font-mono break-all text-xs font-bold">
                  {cipherResult.plaintext}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Global Distributed Honeypot Telemetry Grid */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold font-cyber text-slate-100">
              Global Honeypot Defense Mesh (8 Worldwide Nodes)
            </h3>
          </div>
          <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
            ACTIVE SENTINELS
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {nodes.map((node) => (
            <div
              key={node.id}
              className="p-3 rounded-xl border border-slate-800 bg-slate-950/70 space-y-2 hover:border-cyan-500/40 transition-all text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold font-cyber text-slate-200">{node.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {node.status}
                </span>
              </div>

              <div className="space-y-1 text-[11px] text-slate-400">
                <div className="flex justify-between">
                  <span>Latency:</span>
                  <span className="text-cyan-300">{node.latencyMs}ms</span>
                </div>
                <div className="flex justify-between">
                  <span>Attacks Blocked:</span>
                  <span className="text-emerald-400 font-bold">{node.attacksBlocked}</span>
                </div>
                <div className="flex justify-between">
                  <span>Telemetry Pings:</span>
                  <span className="text-slate-300">{node.pings}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
