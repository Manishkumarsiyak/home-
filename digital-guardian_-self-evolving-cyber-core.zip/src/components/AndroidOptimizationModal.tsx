import React from 'react';
import { Smartphone, BatteryCharging, Bell, CheckCircle2, X, ShieldAlert, Cpu } from 'lucide-react';
import { triggerHaptic } from '../utils/audio';

interface AndroidOptimizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'hi' | 'en' | 'dual';
}

export const AndroidOptimizationModal: React.FC<AndroidOptimizationModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  if (!isOpen) return null;

  const handleRequestNotifications = async () => {
    triggerHaptic('medium');
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        new Notification(
          language === 'hi' ? '🛡️ डिजिटल गार्जियन' : '🛡️ Digital Guardian',
          {
            body: language === 'hi' ? 'सुरक्षा अलर्ट सफलतापूर्वक सक्रिय हो गए हैं!' : 'Cyber security alerts successfully active!',
            icon: '/pwa-192x192.png'
          }
        );
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-lg rounded-2xl border border-emerald-500/40 bg-slate-900 p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-emerald-400 font-bold font-cyber text-sm sm:text-base">
            <Smartphone className="w-5 h-5" />
            <span>
              {language === 'hi' 
                ? '📱 Android फ़ोन में 24/7 बिना रुके चलने की सेटिंग्स' 
                : 'Android 24/7 Background Persistence Guide'}
            </span>
          </div>
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-slate-300 leading-relaxed">
          {language === 'hi'
            ? 'Xiaomi, Samsung, Realme, OnePlus, Vivo जैसे फोन बैकग्राउंड ऐप्स को बैटरी बचाने के लिए बंद कर देते हैं। गार्जियन को 24 घंटे सक्रिय रखने के लिए ये 3 आसान सेटिंग्स करें:'
            : 'Modern Android OEM systems aggressively kill background services. Complete these 3 quick settings to keep Digital Guardian active 24/7:'}
        </p>

        <div className="space-y-3">
          {/* Setting 1: Battery Unrestricted */}
          <div className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/70 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <BatteryCharging className="w-4 h-4 shrink-0" />
              <span>{language === 'hi' ? '1. बैटरी सेवर से छूट (Unrestricted Battery)' : '1. Disable Battery Restrictions'}</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {language === 'hi'
                ? 'फ़ोन की Settings > Apps > डिजिटल गार्जियन > Battery में जाएं और "Unrestricted" या "No Restrictions" चुनें।'
                : 'Navigate to Android Settings > Apps > Digital Guardian > Battery and select "Unrestricted" / "No Restrictions".'}
            </p>
          </div>

          {/* Setting 2: Autostart */}
          <div className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/70 space-y-1.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <Cpu className="w-4 h-4 shrink-0" />
              <span>{language === 'hi' ? '2. ऑटो-स्टार्ट चालू करें (Autostart)' : '2. Enable Autostart on Boot'}</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {language === 'hi'
                ? 'अगर आपके फ़ोन में "Autostart" विकल्प है, तो इसे ON करें ताकि फ़ोन रीस्टार्ट होने पर भी सुरक्षा चालू रहे।'
                : 'Toggle "Autostart" ON in app permissions so defense persists after device reboots.'}
            </p>
          </div>

          {/* Setting 3: Live Notifications */}
          <div className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/70 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Bell className="w-4 h-4 shrink-0" />
              <span>{language === 'hi' ? '3. सुरक्षा नोटिफिकेशन अनुमति' : '3. Security Notifications'}</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {language === 'hi'
                ? 'वायरस या खतरे का तुरंत अलर्ट पाने के लिए नीचे बटन दबाकर नोटिफिकेशन अनुमति चालू करें:'
                : 'Grant notification permission to receive instant high-priority alerts when threats are blocked:'}
            </p>
            <button
              onClick={handleRequestNotifications}
              className="px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 font-bold flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? '🔔 नोटिफिकेशन चालू करें' : 'Enable Notifications'}</span>
            </button>
          </div>
        </div>

        <button
          onClick={() => {
            triggerHaptic('light');
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 font-bold text-slate-950 text-center transition-all"
        >
          {language === 'hi' ? 'समझ गया, धन्यवाद! ✅' : 'Understood, Continue ✅'}
        </button>
      </div>
    </div>
  );
};
