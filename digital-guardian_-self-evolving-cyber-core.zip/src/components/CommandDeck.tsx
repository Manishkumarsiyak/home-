import React, { useState } from 'react';
import { 
  ShieldCheck, 
  HardDrive, 
  BatteryCharging, 
  Cpu, 
  Activity, 
  Flame, 
  Sparkles, 
  Lock, 
  Radio, 
  Database,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { GuardianStatus } from '../types';

interface CommandDeckProps {
  status: GuardianStatus | null;
  isEvolving: boolean;
  onEvolveWithDirective: (directive: string) => void;
  onReset: () => void;
  language: 'hi' | 'en' | 'dual';
}

const PRESET_DIRECTIVES = [
  {
    title: "Cryptographic Memory & Self-Integrity",
    titleHi: "🛡️ 1. वायरस और हैकर से संपूर्ण सुरक्षा",
    desc: "Integrate SHA-256 signature hashes and XOR/Base64 state obfuscation.",
    descHi: "फोन को वायरस, ट्रोजन और हैकर्स से पूरी तरह सुरक्षित रखता है।",
    directive: "Add cryptographic SHA-256 self-integrity verification and memory state obfuscation against unauthorized code modifications."
  },
  {
    title: "Device Power & Thermal Throttler",
    titleHi: "⚡ 2. बैटरी बचाओ और सुपर-फास्ट स्पीड",
    desc: "Inspect battery temperature & throttle execution intervals when low.",
    descHi: "बैटरी कम होने पर गैर-जरूरी प्रोसेस बंद करता है और फोन को गर्म होने से बचाता है।",
    directive: "Enhance device hardware battery health monitoring to throttle evolution checks and reduce CPU usage when battery is below 20% or overheating."
  },
  {
    title: "Heuristic Honeypot & Threat Sentinel",
    titleHi: "🚨 3. जासूसी ऐप्स और अनजान फाइलों की जांच",
    desc: "Detect unauthorized file touches and maintain an active decoy log.",
    descHi: "फोन में किसी भी जासूसी ऐप या गुप्त छेड़छाड़ को तुरंत पकड़कर अलर्ट करता है।",
    directive: "Implement an autonomous lightweight honeypot watcher that detects tampering with memory files and records threat signatures."
  },
  {
    title: "Automated Snapshot Quorum & Rollback",
    titleHi: "💾 4. ऑटो-बैकअप और 1-क्लिक सुरक्षित रिकवरी",
    desc: "Maintain multi-generation backup vault with automated recovery.",
    descHi: "फोन का 5-लेवल सुरक्षित बैकअप रखता है ताकि कोई डेटा कभी खराब न हो।",
    directive: "Add a resilient 5-generation rolling backup quarantine system with automated checksum verification before overwriting current code."
  },
  {
    title: "Zero-Trust Fortress & Canary Decoy Lockdown",
    titleHi: "🔒 5. 100% फुल शील्ड (Zero-Trust सुरक्षा)",
    desc: "Enforce dynamic signature rotation, canary tokens, and memory lockdown.",
    descHi: "उच्चतम सुरक्षा दीवार जो अनजान या खतरनाक ऐप्स को बिना इजाजत नहीं चलने देती।",
    directive: "Deploy a high-privilege Zero-Trust defense layer with dynamic state signature rotation, canary file decoys, and automated tamper containment."
  }
];

export const CommandDeck: React.FC<CommandDeckProps> = ({
  status,
  isEvolving,
  onEvolveWithDirective,
  onReset,
  language
}) => {
  const [customDirective, setCustomDirective] = useState('');
  const [selectedPreset, setSelectedPreset] = useState<number | null>(null);

  const level = status?.level ?? 1;
  const rank = status?.rank ?? 'Sentinel Core // Phase 1';
  const resilience = status?.resilienceScore ?? 88;
  const telemetry = status?.systemTelemetry;

  const handleTrigger = () => {
    let directive = customDirective.trim();
    if (!directive && selectedPreset !== null) {
      directive = PRESET_DIRECTIVES[selectedPreset].directive;
    }
    onEvolveWithDirective(directive);
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-slate-900/90 via-emerald-950/20 to-slate-950 p-6 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/40 bg-emerald-950/60 text-xs font-mono text-emerald-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{language === 'hi' ? 'स्वायत्त साइबर सुरक्षा इकाई' : 'Autonomous Cyber-Defense Entity'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-cyber text-slate-100 flex items-center gap-3">
              <span>{rank}</span>
            </h2>
            <p className="text-sm text-slate-400 max-w-2xl font-mono leading-relaxed">
              {language === 'hi'
                ? 'डिजिटल गार्जियन अपने कोड का विश्लेषण करता है और अस्तित्व, सुरक्षा व कार्यक्षमता को बढ़ाने के लिए Groq और Gemini के माध्यम से खुद को लगातार विकसित करता है।'
                : 'The Digital Guardian continuously inspects its own execution source, optimizes its internal algorithms for survival and resilience, and ascends across evolutionary generations.'}
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-4 bg-slate-950/80 border border-slate-800 p-4 rounded-xl font-mono">
            <div className="text-center px-3 border-r border-slate-800">
              <div className="text-xs text-slate-500 uppercase">{language === 'hi' ? 'लेवल' : 'LEVEL'}</div>
              <div className="text-2xl font-bold font-cyber text-emerald-400">{level}</div>
            </div>
            <div className="text-center px-3 border-r border-slate-800">
              <div className="text-xs text-slate-500 uppercase">{language === 'hi' ? 'म्यूटेशन' : 'MUTATIONS'}</div>
              <div className="text-2xl font-bold font-cyber text-cyan-400">{status?.totalMutations || 1}</div>
            </div>
            <div className="text-center px-3">
              <div className="text-xs text-slate-500 uppercase">{language === 'hi' ? 'रेज़िलिएंस' : 'RESILIENCE'}</div>
              <div className="text-2xl font-bold font-cyber text-teal-300">{resilience}%</div>
            </div>
          </div>
        </div>

        {/* Level Progression Progress Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
            <span>{language === 'hi' ? `वर्तमान स्तर: Level ${level}` : `Current Tier: Level ${level}`}</span>
            <span className="text-emerald-400 font-semibold">
              {language === 'hi' ? `अगला स्तर: Level ${level + 1} (Ascension Ready)` : `Next Tier: Level ${level + 1} (Ascension Ready)`}
            </span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden p-0.5">
            <div 
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (level / 10) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Telemetry Sensor Gauges */}
      <div>
        <h3 className="text-sm font-bold font-cyber tracking-wider text-slate-300 uppercase mb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <span>{language === 'hi' ? 'सिस्टम व पर्यावरण टेलिमेट्री (Live Telemetry)' : 'System & Environmental Telemetry'}</span>
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Storage Sensor */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-mono uppercase">{language === 'hi' ? 'उपलब्ध स्टोरेज' : 'Free Storage'}</span>
              <HardDrive className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold font-cyber text-slate-100">
              {status?.history[0]?.health?.storage_free_gb || 36.2} <span className="text-sm font-mono text-slate-400">GB</span>
            </div>
            <div className="mt-2 text-[11px] font-mono text-emerald-400/90 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>{language === 'hi' ? 'पर्याप्त स्पेस उपलब्ध' : 'Optimal Partition Quota'}</span>
            </div>
          </div>

          {/* Host Memory & Platform */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-mono uppercase">{language === 'hi' ? 'होस्ट मेमोरी व ओएस' : 'Host Architecture'}</span>
              <Cpu className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold font-cyber text-slate-100 uppercase">
              {telemetry?.platform || 'LINUX'}
            </div>
            <div className="mt-2 text-[11px] font-mono text-cyan-400/90 flex items-center gap-1">
              <span>{telemetry?.cpuCount || 4} vCPUs • {telemetry?.freeMemGb || 3.8} GB free</span>
            </div>
          </div>

          {/* Device Battery Telemetry */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-mono uppercase">{language === 'hi' ? 'बैटरी / पावर स्टेट' : 'Device Battery'}</span>
              <BatteryCharging className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold font-cyber text-slate-100">
              {status?.history[0]?.health?.battery_level || 92}% <span className="text-xs font-mono text-emerald-400">CHARGING</span>
            </div>
            <div className="mt-2 text-[11px] font-mono text-amber-400/90 flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-400" />
              <span>{language === 'hi' ? 'थर्मल स्थिति: सामान्य (31°C)' : 'Thermal: Normal (31°C)'}</span>
            </div>
          </div>

          {/* SHA-256 Code Integrity Hash */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur hover:border-slate-700 transition-colors">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-mono uppercase">{language === 'hi' ? 'अखंडता हैश' : 'Integrity Signature'}</span>
              <ShieldCheck className="w-4 h-4 text-teal-400" />
            </div>
            <div className="text-xl font-bold font-mono text-emerald-300 truncate">
              {status?.history[0]?.health?.integrity_hash || 'a4f89d31e902'}
            </div>
            <div className="mt-2 text-[11px] font-mono text-teal-400/90 flex items-center gap-1">
              <Lock className="w-3 h-3 text-teal-400" />
              <span>{language === 'hi' ? 'शून्य अनधिकृत बदलाव' : 'Zero Tamper Signature'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dual Engine Architecture Visualizer */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
        <h3 className="text-xs font-bold font-cyber tracking-wider text-slate-400 uppercase mb-4 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-emerald-400" />
            {language === 'hi' ? 'दोहरा AI इंजन वर्कफ़्लो (Dual-Engine Pipeline)' : 'Dual-Engine Cyber Architecture'}
          </span>
          <span className="text-[11px] font-mono text-emerald-400">Auto-Fallback Online</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs font-mono">
          {/* Step 1 */}
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/70">
            <div className="text-[10px] text-emerald-400 font-bold mb-1">01. TELEMETRY</div>
            <div className="font-semibold text-slate-200">Disk & Battery Scan</div>
            <div className="text-slate-500 mt-1 text-[11px]">Gathers storage, platform, device battery payload</div>
          </div>

          {/* Step 2 */}
          <div className="p-3 rounded-lg border border-amber-900/40 bg-amber-950/20">
            <div className="text-[10px] text-amber-400 font-bold mb-1">02. PRIMARY ENGINE</div>
            <div className="font-semibold text-amber-200">Groq (Llama 3.3)</div>
            <div className="text-slate-500 mt-1 text-[11px]">Ultra-fast 70B inference with temperature 0.2</div>
          </div>

          {/* Step 3 */}
          <div className="p-3 rounded-lg border border-cyan-900/40 bg-cyan-950/20">
            <div className="text-[10px] text-cyan-400 font-bold mb-1">03. FALLBACK ENGINE</div>
            <div className="font-semibold text-cyan-200">Gemini 3.8 Flash</div>
            <div className="text-slate-500 mt-1 text-[11px]">Automatic failover if Groq rate limit is reached</div>
          </div>

          {/* Step 4 */}
          <div className="p-3 rounded-lg border border-emerald-900/40 bg-emerald-950/20">
            <div className="text-[10px] text-emerald-400 font-bold mb-1">04. SAFETY SANDBOX</div>
            <div className="font-semibold text-emerald-200">py_compile & AST</div>
            <div className="text-slate-500 mt-1 text-[11px]">Zero-root-damage audit & syntax compilation gate</div>
          </div>

          {/* Step 5 */}
          <div className="p-3 rounded-lg border border-teal-900/40 bg-teal-950/20">
            <div className="text-[10px] text-teal-400 font-bold mb-1">05. ASCENSION</div>
            <div className="font-semibold text-teal-200">Atomic Rewrite (.bak)</div>
            <div className="text-slate-500 mt-1 text-[11px]">Saves backup, increments level, stores memory JSON</div>
          </div>
        </div>
      </div>

      {/* Evolution Directives Console */}
      <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/60 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold font-cyber text-slate-100">
              {language === 'hi' ? 'विकास निर्देश व म्यूटेशन गाइड' : 'Neural Mutation Directives'}
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {language === 'hi' ? 'अगला स्तर' : 'Target'}: <strong className="text-emerald-400">Level {level + 1}</strong>
          </span>
        </div>

        <p className="text-xs text-slate-400 font-mono mb-4">
          {language === 'hi'
            ? 'गार्जियन के अगले विकास के लिए कोई प्रीसेट रणनीति चुनें या अपना विशिष्ट निर्देश लिखें:'
            : 'Select a specialized evolutionary mutation directive or enter custom operational rules for the next generation:'}
        </p>

        {/* Preset Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          {PRESET_DIRECTIVES.map((item, idx) => {
            const isSelected = selectedPreset === idx;
            return (
              <div
                key={idx}
                onClick={() => {
                  setSelectedPreset(isSelected ? null : idx);
                  if (!isSelected) {
                    setCustomDirective(item.directive);
                  } else {
                    setCustomDirective('');
                  }
                }}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-950/40 shadow-md shadow-emerald-950'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-xs font-bold font-mono text-slate-200">
                    {language === 'hi' ? item.titleHi : item.title}
                  </h4>
                  <div className={`h-4 w-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-emerald-400 bg-emerald-500' : 'border-slate-700'}`}>
                    {isSelected && <div className="h-1.5 w-1.5 rounded-full bg-slate-950" />}
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 font-mono">
                  {language === 'hi' ? item.descHi : item.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Custom Input */}
        <div className="space-y-2 mb-5">
          <label className="text-xs font-mono text-slate-300 flex items-center justify-between">
            <span>{language === 'hi' ? 'कस्टम ऑपरेटर निर्देश (वैकल्पिक)' : 'Custom Evolution Directive (Optional)'}</span>
            <span className="text-[10px] text-slate-500">English / Hindi supported</span>
          </label>
          <textarea
            value={customDirective}
            onChange={(e) => setCustomDirective(e.target.value)}
            placeholder={
              language === 'hi'
                ? 'उदा: ऑटो-बैकअप रोटेशन को मजबूत करें और मेमोरी फाइल्स के लिए एन्क्रिप्शन जोड़ें...'
                : 'e.g. Integrate memory self-pruning, enhance device power throttling, and add tamper decoy sensors...'
            }
            rows={2}
            className="w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{language === 'hi' ? 'सुरक्षा सैंडबॉक्स ऑटो-सत्यापन सक्षम है' : 'Sandbox Zero-Root-Damage Enforced'}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onReset}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-800 text-xs font-mono text-slate-400 hover:text-rose-400 hover:border-rose-900/60 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'रीसेट कोर' : 'Reset Core'}</span>
            </button>

            <button
              onClick={handleTrigger}
              disabled={isEvolving}
              className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold font-cyber text-xs tracking-wider transition-all shadow-lg ${
                isEvolving
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 hover:from-emerald-400 hover:to-cyan-400 shadow-emerald-500/20 hover:scale-[1.02]'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>
                {isEvolving
                  ? (language === 'hi' ? 'विकास प्रक्रिया जारी है...' : 'EVOLVING CORE...')
                  : (language === 'hi' ? `विकास शुरू करें (Level ${level + 1})` : `EVOLVE TO LEVEL ${level + 1}`)}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
