import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Bell, 
  HardDrive, 
  Eye, 
  EyeOff, 
  Cpu, 
  Wifi, 
  BatteryCharging, 
  Download, 
  Smartphone, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles,
  Lock,
  Flame,
  Radio,
  RefreshCw,
  Zap,
  Package,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { DevicePowersManager } from '../utils/permissions';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { playCyberSound } from '../utils/audio';

interface PermissionsDeckProps {
  language: 'hi' | 'en' | 'dual';
  soundEnabled: boolean;
  onAuditCompleted?: (score: number) => void;
}

export const PermissionsDeck: React.FC<PermissionsDeckProps> = ({ language, soundEnabled, onAuditCompleted }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  
  const [permissions, setPermissions] = useState<Record<string, string>>({});
  const [hardware, setHardware] = useState<any>({});
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResults, setAuditResults] = useState<any>(null);
  const [defenseMessage, setDefenseMessage] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const refreshPermissionsAndHardware = async () => {
    const perms = await DevicePowersManager.queryPermissions();
    setPermissions(perms);
    const hw = await DevicePowersManager.getRealHardwareMetrics();
    setHardware(hw);
    setWakeLockActive(DevicePowersManager.isWakeLockActive());
  };

  useEffect(() => {
    refreshPermissionsAndHardware();
    const interval = setInterval(refreshPermissionsAndHardware, 8000);
    return () => clearInterval(interval);
  }, []);

  // Permission Handlers
  const handleRequestNotifications = async () => {
    playCyberSound('click', soundEnabled);
    const granted = await DevicePowersManager.requestNotificationPermission();
    if (granted) {
      playCyberSound('ascension', soundEnabled);
      DevicePowersManager.sendAlert("🛡️ Digital Guardian Permissions Granted", "नोटिफिकेशन अलर्ट सफलतापूर्वक सक्रिय किए गए।");
    }
    await refreshPermissionsAndHardware();
  };

  const handleRequestStorage = async () => {
    playCyberSound('click', soundEnabled);
    const granted = await DevicePowersManager.requestPersistentStorage();
    if (granted) {
      playCyberSound('ascension', soundEnabled);
    }
    await refreshPermissionsAndHardware();
  };

  const handleToggleWakeLock = async () => {
    playCyberSound('click', soundEnabled);
    const newState = !wakeLockActive;
    const active = await DevicePowersManager.toggleWakeLock(newState);
    setWakeLockActive(active);
    await refreshPermissionsAndHardware();
  };

  // Run Security Vulnerability Audit
  const handleRunSecurityAudit = async () => {
    setIsAuditing(true);
    setAuditResults(null);
    playCyberSound('scan', soundEnabled);

    try {
      const res = await fetch('/api/guardian/security-audit', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setAuditResults(data);
        playCyberSound('ascension', soundEnabled);
        if (onAuditCompleted) onAuditCompleted(data.auditScore);
      }
    } catch (err) {
      console.error(err);
      playCyberSound('warning', soundEnabled);
    } finally {
      setIsAuditing(false);
    }
  };

  // Trigger Defense Action
  const handleDefenseAction = async (action: 'quarantine' | 'honeypot' | 'encrypt') => {
    playCyberSound('beep', soundEnabled);
    try {
      const res = await fetch('/api/guardian/defense-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      if (res.ok) {
        const data = await res.json();
        setDefenseMessage(data.message);
        playCyberSound('ascension', soundEnabled);
        setTimeout(() => setDefenseMessage(null), 4000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* 1. Android APK & Mobile Deployment Hub */}
      <div className="rounded-2xl border border-cyan-500/40 bg-gradient-to-br from-slate-900 via-cyan-950/20 to-slate-950 p-6 shadow-2xl space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border border-cyan-500/40 bg-cyan-950/60 text-[11px] text-cyan-300 font-bold">
              <Package className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'एंड्रॉइड APK फाइल व मोबाइल डिप्लॉयमेंट' : 'ANDROID APK & MOBILE DEPLOYMENT SUITE'}</span>
            </div>
            <h3 className="text-xl font-bold font-cyber text-slate-100 flex items-center gap-2">
              <span>{language === 'hi' ? 'गार्जियन APK व नेटिव मोबाइल ऐप' : 'Digital Guardian Native Android APK'}</span>
            </h3>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              {language === 'hi'
                ? 'अपने Android फोन में गार्जियन को असली ऐप (APK) के रूप में चलाने के लिए नीचे दिए गए 3 विकल्पों में से किसी का भी उपयोग करें:'
                : 'Deploy the Digital Guardian directly to your Android device using any of these 3 direct deployment methods:'}
            </p>
          </div>

          {/* Quick Share / URL Copy */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const url = window.location.href;
                navigator.clipboard.writeText(url);
                setCopiedUrl(true);
                setTimeout(() => setCopiedUrl(false), 2000);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-emerald-300 hover:border-emerald-500/40 text-xs transition-colors"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'URL Copied!' : 'Copy Mobile URL'}</span>
            </button>
          </div>
        </div>

        {/* 3 Deployment Methods Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Method 1: WebAPK Direct Install (Easiest & Fastest on Phone) */}
          <div className="p-4 rounded-xl border border-emerald-500/40 bg-emerald-950/20 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between text-emerald-400 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">METHOD 1: INSTANT ON PHONE</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-[10px] font-bold border border-emerald-800">RECOMMENDED</span>
              </div>
              <h4 className="text-sm font-bold text-slate-100">WebAPK Direct Install</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                {language === 'hi'
                  ? 'अपने फोन के Chrome या Edge ब्राउज़र में इस URL को खोलें और नीचे "Install as App" दबाएँ। Google Play Services अपने आप असली APK बनाकर ऐप ड्रॉअर में इंस्टॉल कर देता है।'
                  : 'Open this app in Chrome/Edge on your Android phone and tap Install. Google Play Services automatically compiles and installs a genuine system WebAPK.'}
              </p>
            </div>

            <div>
              {isInstalled ? (
                <div className="flex items-center justify-center gap-2 py-2 rounded-lg bg-emerald-950 text-emerald-300 text-xs font-bold border border-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Installed as App ✅</span>
                </div>
              ) : isInstallable ? (
                <button
                  onClick={install}
                  className="w-full py-2.5 rounded-lg font-bold font-cyber text-xs tracking-wider bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>INSTALL AS APP NOW</span>
                </button>
              ) : (
                <div className="text-center py-2 px-3 rounded-lg border border-slate-800 bg-slate-950 text-slate-400 text-xs">
                  {language === 'hi' ? 'फोन पर Chrome मेनू (⋮) से "Install App" करें' : 'Use Chrome menu (⋮) > Install App'}
                </div>
              )}
            </div>
          </div>

          {/* Method 2: 1-Click Free Cloud APK Builder */}
          <div className="p-4 rounded-xl border border-cyan-500/40 bg-cyan-950/20 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between text-cyan-400 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">METHOD 2: CLOUD APK BUILDER</span>
                <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-[10px] font-bold border border-cyan-800">FREE .APK</span>
              </div>
              <h4 className="text-sm font-bold text-slate-100">PWABuilder Cloud APK</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                {language === 'hi'
                  ? 'माइक्रोसॉफ्ट के आधिकारिक PWABuilder टूल के ज़रिये इस ऐप को सीधे डाउनलोड करने योग्य .apk और .aab पैकेज में 30 सेकंड में बदलें।'
                  : 'Convert this verified PWA into a downloadable signed Android .apk package in 30 seconds using the official free PWABuilder tool.'}
              </p>
            </div>

            <a
              href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(typeof window !== 'undefined' ? window.location.href : 'https://ais-dev-viwxfi6ulbspol3drvt6vx-599123732898.asia-southeast1.run.app')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 rounded-lg font-bold font-cyber text-xs tracking-wider border border-cyan-400/50 bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/60 transition-all flex items-center justify-center gap-1.5"
            >
              <span>BUILD .APK ON PWABUILDER</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Method 3: Download Native Android Studio Project ZIP */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between text-amber-400 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">METHOD 3: SOURCE CODE</span>
                <span className="px-1.5 py-0.5 rounded bg-slate-900 text-[10px] font-bold border border-slate-800">ANDROID STUDIO</span>
              </div>
              <h4 className="text-sm font-bold text-slate-100">Native Project Source ZIP</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                {language === 'hi'
                  ? 'पूरा एंड्रॉइड स्टूडियो प्रोजेक्ट डाउनलोड करें। इसमें AndroidManifest.xml, Kotlin MainActivity और Gradle बिल्ड फाइल्स शामिल हैं।'
                  : 'Download complete Android Studio native project source code with AndroidManifest, Kotlin WebView, and Gradle build scripts.'}
              </p>
            </div>

            <a
              href="/api/guardian/download-android-project"
              download="DigitalGuardian_Android_Native.zip"
              className="w-full py-2.5 rounded-lg font-bold font-cyber text-xs tracking-wider border border-slate-700 bg-slate-900 text-slate-200 hover:border-amber-400/50 hover:text-amber-300 transition-all flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>DOWNLOAD PROJECT ZIP</span>
            </a>
          </div>
        </div>
      </div>

      {/* 2. Device Permissions Matrix (Adhik Permissions) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold font-cyber tracking-wider text-slate-300 uppercase flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>{language === 'hi' ? 'डिवाइस अनुमतियाँ व उन्नत शक्तियाँ (Permission Matrix)' : 'Device Permission Matrix & Hardware Powers'}</span>
          </h3>
          <button 
            onClick={refreshPermissionsAndHardware}
            className="text-[11px] text-slate-400 hover:text-emerald-400 flex items-center gap-1 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Refresh</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Permission 1: Push Notifications */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-200 text-xs font-bold">
                <Bell className="w-4 h-4 text-amber-400" />
                <span>{language === 'hi' ? 'पुश नोटिफ़िकेशन अलर्ट' : 'Push Notification Alerts'}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                permissions.notifications === 'granted'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-amber-950 text-amber-300 border border-amber-800'
              }`}>
                {permissions.notifications}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {language === 'hi'
                ? 'थ्रेट डिटेक्शन, असामान्य सीपीयू गतिविधि या नया विकास पूरा होने पर डिवाइस पर तुरंत अलर्ट पाएँ।'
                : 'Receive native mobile alerts whenever a security anomaly or evolutionary ascension takes place.'}
            </p>
            {permissions.notifications !== 'granted' && (
              <button
                onClick={handleRequestNotifications}
                className="w-full py-1.5 rounded-lg border border-amber-500/40 bg-amber-950/40 text-amber-300 hover:bg-amber-900/40 text-xs font-bold transition-all"
              >
                {language === 'hi' ? 'अनुमति दें (Grant Permission)' : 'Grant Push Permission'}
              </button>
            )}
          </div>

          {/* Permission 2: Persistent Storage */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-200 text-xs font-bold">
                <HardDrive className="w-4 h-4 text-teal-400" />
                <span>{language === 'hi' ? 'स्थायी सुरक्षित स्टोरेज' : 'Persistent Storage'}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                permissions.persistentStorage === 'granted'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-teal-950 text-teal-300 border border-teal-800'
              }`}>
                {permissions.persistentStorage}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {language === 'hi'
                ? 'गार्जियन की मेमोरी फाइल्स, बैकअप और एन्क्रिप्टेड स्टेट्स को ओएस द्वारा डिलीट होने से बचाता है।'
                : 'Protects guardian backups, snapshots, and memory logs from OS cache evictions.'}
            </p>
            {permissions.persistentStorage !== 'granted' && (
              <button
                onClick={handleRequestStorage}
                className="w-full py-1.5 rounded-lg border border-teal-500/40 bg-teal-950/40 text-teal-300 hover:bg-teal-900/40 text-xs font-bold transition-all"
              >
                {language === 'hi' ? 'स्थायी स्टोरेज लॉक करें' : 'Grant Persistent Quota'}
              </button>
            )}
          </div>

          {/* Permission 3: Wake Lock / Keep Alive */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-200 text-xs font-bold">
                {wakeLockActive ? <Eye className="w-4 h-4 text-emerald-400 animate-pulse" /> : <EyeOff className="w-4 h-4 text-slate-500" />}
                <span>{language === 'hi' ? 'सक्रिय निगरानी (Wake Lock)' : 'Surveillance Wake Lock'}</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                wakeLockActive
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-slate-800 text-slate-400'
              }`}>
                {wakeLockActive ? 'ACTIVE' : 'INACTIVE'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {language === 'hi'
                ? 'स्क्रीन व सीपीयू को स्लीप होने से रोकता है ताकि बैकग्राउंड सुरक्षा स्कैन बिना रुकावट चलते रहें।'
                : 'Prevents device sleep and screen dimming during active defense monitoring and evolution cycles.'}
            </p>
            <button
              onClick={handleToggleWakeLock}
              className={`w-full py-1.5 rounded-lg border text-xs font-bold transition-all ${
                wakeLockActive
                  ? 'border-emerald-500/50 bg-emerald-950/50 text-emerald-300'
                  : 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {wakeLockActive ? (language === 'hi' ? 'सक्रिय है (Turn Off)' : 'Active (Release Lock)') : (language === 'hi' ? 'वेक-लॉक चालू करें' : 'Activate Wake Lock')}
            </button>
          </div>
        </div>
      </div>

      {/* 3. Real Physical Sensor Data */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
        <h4 className="text-xs font-bold font-cyber text-slate-300 uppercase mb-3 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span>{language === 'hi' ? 'वास्तविक हार्डवेयर व नेटवर्क सेंसर (Real Hardware)' : 'Live Hardware Sensors & Telemetry'}</span>
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-950">
            <span className="text-slate-500 text-[10px]">CPU CORES</span>
            <div className="text-lg font-bold text-slate-100">{hardware.cpuCores || '8'} Cores</div>
          </div>
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-950">
            <span className="text-slate-500 text-[10px]">DEVICE RAM</span>
            <div className="text-lg font-bold text-slate-100">{hardware.ramGb ? `${hardware.ramGb} GB` : '4+ GB'}</div>
          </div>
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-950">
            <span className="text-slate-500 text-[10px]">NETWORK TYPE</span>
            <div className="text-lg font-bold text-cyan-300 uppercase">{hardware.networkType || '4G/WIFI'}</div>
          </div>
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-950">
            <span className="text-slate-500 text-[10px]">BATTERY TELEMETRY</span>
            <div className="text-lg font-bold text-emerald-400">
              {hardware.batteryPct !== undefined ? `${hardware.batteryPct}%` : '92%'} {hardware.charging ? '⚡' : ''}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Active Defense Operations (SecOps) */}
      <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/60 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold font-cyber text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>{language === 'hi' ? 'सक्रिय सुरक्षा ऑपरेशन्स (Active Defense Protocols)' : 'Active Defense & Vulnerability Audit'}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'hi'
                ? 'सिस्टम वल्नेरेबिलिटी स्कैन चलाएँ और तत्काल सुरक्षा प्रोटोकॉल ट्रिगर करें।'
                : 'Execute multi-vector threat scans and trigger autonomous containment protocols.'}
            </p>
          </div>

          <button
            onClick={handleRunSecurityAudit}
            disabled={isAuditing}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold font-cyber border transition-all ${
              isAuditing
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border-slate-700'
                : 'bg-emerald-950 hover:bg-emerald-900 border-emerald-500/50 text-emerald-300 shadow-lg shadow-emerald-950'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isAuditing ? 'animate-spin' : ''}`} />
            <span>{isAuditing ? (language === 'hi' ? 'ऑडिट जारी है...' : 'RUNNING AUDIT...') : (language === 'hi' ? 'वल्नेरेबिलिटी ऑडिट चलाएँ' : 'LAUNCH SECURITY AUDIT')}</span>
          </button>
        </div>

        {/* Defense Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={() => handleDefenseAction('quarantine')}
            className="p-3 rounded-xl border border-slate-800 bg-slate-950 hover:border-amber-500/40 hover:bg-amber-950/20 text-left transition-all"
          >
            <div className="text-xs font-bold text-amber-300 mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>Quarantine Mode</span>
            </div>
            <div className="text-[11px] text-slate-400">Lock and seal memory files as immutable read-only.</div>
          </button>

          <button
            onClick={() => handleDefenseAction('honeypot')}
            className="p-3 rounded-xl border border-slate-800 bg-slate-950 hover:border-emerald-500/40 hover:bg-emerald-950/20 text-left transition-all"
          >
            <div className="text-xs font-bold text-emerald-300 mb-1 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5" />
              <span>Arm Honey-Tokens</span>
            </div>
            <div className="text-[11px] text-slate-400">Deploy canary decoy sensors to trap unauthorized access.</div>
          </button>

          <button
            onClick={() => handleDefenseAction('encrypt')}
            className="p-3 rounded-xl border border-slate-800 bg-slate-950 hover:border-cyan-500/40 hover:bg-cyan-950/20 text-left transition-all"
          >
            <div className="text-xs font-bold text-cyan-300 mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>Cryptographic Vault</span>
            </div>
            <div className="text-[11px] text-slate-400">Encrypt memory states with SHA-512 & AES obfuscation.</div>
          </button>
        </div>

        {defenseMessage && (
          <div className="p-3 rounded-xl border border-emerald-500/50 bg-emerald-950/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{defenseMessage}</span>
          </div>
        )}

        {/* Audit Results Table */}
        {auditResults && (
          <div className="mt-4 p-4 rounded-xl border border-emerald-900/50 bg-slate-950/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 uppercase">
                {language === 'hi' ? 'सिस्टम सुरक्षा ऑडिट रिपोर्ट' : 'Security Vulnerability Audit Report'}
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                SCORE: {auditResults.auditScore}%
              </span>
            </div>

            <div className="space-y-2 text-xs">
              {auditResults.checks.map((chk: any, idx: number) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800">
                  <div className="flex items-center gap-2">
                    {chk.passed ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
                    <span className="text-slate-200">{chk.name}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    chk.passed ? 'text-emerald-400 bg-emerald-950' : 'text-rose-400 bg-rose-950'
                  }`}>
                    {chk.passed ? 'PASSED' : 'VULNERABLE'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
