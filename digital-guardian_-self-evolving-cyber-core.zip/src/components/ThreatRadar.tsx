import React, { useState, useEffect } from 'react';
import { 
  Radar, 
  ShieldAlert, 
  Radio, 
  Activity, 
  Lock, 
  Crosshair, 
  Flame, 
  CheckCircle2, 
  AlertTriangle,
  Zap,
  Play
} from 'lucide-react';
import { playCyberSound } from '../utils/audio';

interface ThreatEvent {
  id: string;
  name: string;
  type: string;
  origin: string;
  timestamp: string;
  status: 'intercepted' | 'contained' | 'neutralized';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
}

interface ThreatRadarProps {
  language: 'hi' | 'en' | 'dual';
  soundEnabled: boolean;
  onThreatIntercepted: (msg: string) => void;
}

export const ThreatRadar: React.FC<ThreatRadarProps> = ({
  language,
  soundEnabled,
  onThreatIntercepted
}) => {
  const [threatCount, setThreatCount] = useState(14820);
  const [simulating, setSimulating] = useState(false);
  const [activeAlert, setActiveAlert] = useState<string | null>(null);
  
  const [threats, setThreats] = useState<ThreatEvent[]>([
    {
      id: 'th-1',
      name: 'Path Traversal /etc/passwd Probe',
      type: 'INJECTION_ATTEMPT',
      origin: '185.220.101.44 (Tor Node)',
      timestamp: new Date(Date.now() - 14000).toLocaleTimeString(),
      status: 'neutralized',
      severity: 'HIGH'
    },
    {
      id: 'th-2',
      name: 'Honey-Token Decoy Canary Probe',
      type: 'CANARY_TRIP',
      origin: '194.26.29.112 (Scanner)',
      timestamp: new Date(Date.now() - 42000).toLocaleTimeString(),
      status: 'contained',
      severity: 'CRITICAL'
    },
    {
      id: 'th-3',
      name: 'SYN Flood Exhaustion Anomaly',
      type: 'DOS_SURGE',
      origin: 'Distributed Botnet (Subnet /24)',
      timestamp: new Date(Date.now() - 98000).toLocaleTimeString(),
      status: 'intercepted',
      severity: 'MEDIUM'
    }
  ]);

  // Periodic random threat deflection counter increment
  useEffect(() => {
    const timer = setInterval(() => {
      setThreatCount(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  // Simulate Attack Handler
  const handleSimulateAttack = (attackType: string) => {
    setSimulating(true);
    playCyberSound('warning', soundEnabled);

    let threatTitle = "Simulated Threat Probe";
    if (attackType === 'sqli') threatTitle = "SQLi / Auth Bypass Vector";
    if (attackType === 'canary') threatTitle = "Unauthorized Canary Decoy File Touch";
    if (attackType === 'rootkit') threatTitle = "Malicious Rootkit Injection ('rm -rf /' payload)";

    setActiveAlert(`THREAT INCOMING: ${threatTitle}`);

    setTimeout(() => {
      playCyberSound('ascension', soundEnabled);
      setActiveAlert(null);
      setSimulating(false);

      const newThreat: ThreatEvent = {
        id: `th-${Date.now()}`,
        name: threatTitle,
        type: attackType.toUpperCase(),
        origin: 'Simulated Red-Team Vector',
        timestamp: new Date().toLocaleTimeString(),
        status: 'neutralized',
        severity: 'CRITICAL'
      };

      setThreats(prev => [newThreat, ...prev.slice(0, 5)]);
      setThreatCount(prev => prev + 1);
      onThreatIntercepted(`[Defense Radar]: ${threatTitle} को सैंडबॉक्स शील्ड द्वारा 18ms में निष्प्रभावी किया गया (Zero Damage ✅)`);
    }, 1800);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* 1. Radar Banner */}
      <div className="rounded-2xl border border-emerald-500/40 bg-gradient-to-r from-slate-900 via-emerald-950/20 to-slate-950 p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/40 bg-emerald-950/60 text-xs text-emerald-300 font-bold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>PRO THREAT INTERCEPTION RADAR // 360° HEURISTICS</span>
            </div>
            <h2 className="text-2xl font-bold font-cyber text-slate-100 flex items-center gap-2">
              <span>{language === 'hi' ? 'लाइव साइबर वॉर-रूम व रडार' : 'Cyber Threat Radar & Interceptor'}</span>
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              {language === 'hi'
                ? 'गार्जियन का 100x प्रो-लेवल रडार सभी इनबाउंड और आउटबाउंड थ्रेट वेक्टर्स, मेमोरी लीक्स और डिकॉय ट्रैप्स की 24/7 सक्रिय निगरानी करता है।'
                : 'Military-grade 360° heuristic radar monitoring system anomalies, honeypot canary trips, and malicious injection payloads in real-time.'}
            </p>
          </div>

          {/* Radar Animation Graphic */}
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full border-2 border-emerald-500/40 bg-slate-950/80 flex items-center justify-center shadow-xl shadow-emerald-950">
            {/* Concentric rings */}
            <div className="absolute inset-4 rounded-full border border-emerald-500/20" />
            <div className="absolute inset-10 rounded-full border border-emerald-500/30" />
            <div className="absolute inset-16 rounded-full border border-emerald-500/40" />
            
            {/* Crosshairs */}
            <div className="absolute inset-x-0 top-1/2 h-0.5 bg-emerald-500/20" />
            <div className="absolute inset-y-0 left-1/2 w-0.5 bg-emerald-500/20" />

            {/* Rotating radar sweep */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-emerald-500/10 to-emerald-400/30 animate-spin origin-center" style={{ animationDuration: '4s' }} />

            {/* Radar Center Beacon */}
            <div className="relative z-10 p-2 rounded-full bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-400">
              <Crosshair className="w-5 h-5 animate-pulse" />
            </div>

            {/* Random blips */}
            <div className="absolute top-8 right-12 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <div className="absolute bottom-10 left-10 w-2 h-2 rounded-full bg-amber-400 animate-ping" style={{ animationDelay: '1.2s' }} />
          </div>
        </div>

        {/* Live Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-4 border-t border-slate-800">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase">INTERCEPTED ATTACKS</span>
            <div className="text-xl font-bold font-cyber text-emerald-400">{threatCount.toLocaleString()}</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase">DEFENSE SUCCESS RATE</span>
            <div className="text-xl font-bold font-cyber text-cyan-400">99.98%</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase">RESPONSE LATENCY</span>
            <div className="text-xl font-bold font-cyber text-teal-300">14 ms</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase">ACTIVE CANARIES</span>
            <div className="text-xl font-bold font-cyber text-amber-400">16 Deployed</div>
          </div>
        </div>
      </div>

      {/* 2. Interactive Attack Simulation Suite */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold font-cyber text-slate-100 uppercase">
              {language === 'hi' ? 'लाइव साइबर अटैक सिमुलेटर (Penetration Test)' : 'Red-Team Attack Simulator (Penetration Testing)'}
            </h3>
          </div>
          <span className="text-xs text-slate-500">Test Guardian Defenses</span>
        </div>

        <p className="text-xs text-slate-400">
          {language === 'hi'
            ? 'नीचे दिए गए सिमुलेटेड हमलों में से किसी को भी ट्रिगर करके देखें कि गार्जियन कैसे रियल-टाइम में उसे तुरंत पकड़कर निष्प्रभावी करता है:'
            : 'Trigger a controlled penetration simulation to verify real-time AST quarantine, honeypot traps, and payload neutralization:'}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={() => handleSimulateAttack('sqli')}
            disabled={simulating}
            className="p-3.5 rounded-xl border border-slate-800 bg-slate-950 hover:border-amber-500/50 hover:bg-amber-950/20 text-left transition-all group"
          >
            <div className="text-xs font-bold text-amber-300 mb-1 flex items-center justify-between">
              <span>SQLi / Auth Bypass</span>
              <Play className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>
            <div className="text-[11px] text-slate-400">Injects unauthorized SQL/AST manipulation vectors.</div>
          </button>

          <button
            onClick={() => handleSimulateAttack('canary')}
            disabled={simulating}
            className="p-3.5 rounded-xl border border-slate-800 bg-slate-950 hover:border-emerald-500/50 hover:bg-emerald-950/20 text-left transition-all group"
          >
            <div className="text-xs font-bold text-emerald-300 mb-1 flex items-center justify-between">
              <span>Honey-Token Trip</span>
              <Play className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </div>
            <div className="text-[11px] text-slate-400">Triggers hidden canary trap token tampering.</div>
          </button>

          <button
            onClick={() => handleSimulateAttack('rootkit')}
            disabled={simulating}
            className="p-3.5 rounded-xl border border-slate-800 bg-slate-950 hover:border-rose-500/50 hover:bg-rose-950/20 text-left transition-all group"
          >
            <div className="text-xs font-bold text-rose-300 mb-1 flex items-center justify-between">
              <span>Root Destruction ('rm -rf')</span>
              <Play className="w-3.5 h-3.5 text-slate-500 group-hover:text-rose-400 transition-colors" />
            </div>
            <div className="text-[11px] text-slate-400">Tests 0-damage gate against destructive shell commands.</div>
          </button>
        </div>

        {/* Live Attack Alert Banner */}
        {activeAlert && (
          <div className="p-3 rounded-xl border border-rose-500 bg-rose-950/80 text-rose-200 text-xs flex items-center gap-2 animate-pulse">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-bold">{activeAlert}</span>
            <span className="ml-auto text-[10px] px-2 py-0.5 rounded bg-rose-900 font-bold">ANALYZING...</span>
          </div>
        )}
      </div>

      {/* 3. Live Threat Event Intercept Feed */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-xl">
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-slate-200">
              {language === 'hi' ? 'लाइव इंटरसेप्टेड अटैक लॉग (Heuristic Feed)' : 'Live Intercepted Threat Feed'}
            </span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-900">
            ZERO BREACHES
          </span>
        </div>

        <div className="divide-y divide-slate-800/80 text-xs">
          {threats.map((th) => (
            <div key={th.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-900/40 transition-colors">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                    th.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                    th.severity === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {th.severity}
                  </span>
                  <span className="font-bold text-slate-200">{th.name}</span>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center gap-2">
                  <span>Origin: <strong className="text-slate-400">{th.origin}</strong></span>
                  <span>•</span>
                  <span>Type: <strong className="text-slate-400">{th.type}</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0 text-[11px]">
                <span className="text-slate-500">{th.timestamp}</span>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span className="uppercase">{th.status}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
