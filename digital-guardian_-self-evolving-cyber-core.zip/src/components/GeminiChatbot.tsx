import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Shield, 
  Terminal, 
  RotateCcw, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Zap, 
  Cpu, 
  Download, 
  AlertOctagon,
  User,
  Radio
} from 'lucide-react';
import { ChatMessage, GuardianStatus } from '../types';
import { playCyberSound } from '../utils/audio';

interface GeminiChatbotProps {
  status: GuardianStatus | null;
  language: 'hi' | 'en' | 'dual';
  soundEnabled: boolean;
  onExecuteAction: (action: string) => void;
  onEvolveTrigger: () => void;
  onNavigateTab: (tab: string) => void;
}

export const GeminiChatbot: React.FC<GeminiChatbotProps> = ({
  status,
  language,
  soundEnabled,
  onExecuteAction,
  onEvolveTrigger,
  onNavigateTab
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      role: 'model',
      text: language === 'hi'
        ? `🛡️ **[गार्जियन 1000X AI कोर ऑनलाइन]:**\nनमस्ते ऑपरेटर! मैं आपका **Autonomous Cyber Sentinel** हूँ।\n- लेवल: **${status?.level || 1} (${status?.rank || 'Sentinel Core'})**\n- सक्रिय मॉडल: **Gemini 3.8 Flash**\n- रेजिलिएंस स्कोर: **${status?.resilienceScore || 88}%**\n\nआप मुझसे म्यूटेशन कोड, स्टैंडअलोन APK इंस्टॉलेशन, वल्नेरेबिलिटी स्कैन या सिस्टम हार्डनिंग के बारे में कोई भी प्रश्न पूछ सकते हैं।`
        : `🛡️ **[GUARDIAN 1000X NEURAL AI ONLINE]:**\nGreetings, Operator. I am your **Autonomous Cyber Sentinel AI** powered by Gemini.\n- Core Level: **${status?.level || 1} (${status?.rank || 'Sentinel Core'})**\n- Active Model: **Gemini 3.8 Flash**\n- Defense Resilience: **${status?.resilienceScore || 88}%**\n\nAsk me anything regarding autonomous self-evolution, direct Android APK deployment, or cryptographic hardening.`,
      timestamp: new Date().toLocaleTimeString(),
      modelUsed: 'gemini-3.8-flash'
    }
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [ttsEnabled, setTtsEnabled] = useState(false);
  
  // Model selection state
  const [selectedModel, setSelectedModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite' | 'gemini-4-argon'>('gemini-3.8-flash');
  
  // Role persona state
  const [selectedPersona, setSelectedPersona] = useState<'sentinel' | 'tactician' | 'analyst' | 'overmind'>('sentinel');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Text to Speech
  const speakMessage = (text: string) => {
    if (!('speechSynthesis' in window) || !ttsEnabled) return;
    try {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#`_\[\]]/g, '').slice(0, 220);
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.pitch = 0.9;
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    } catch {}
  };

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input.trim();
    if (!textToSend || loading) return;

    playCyberSound('click', soundEnabled);

    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString()
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      // Map history excluding welcome and current
      const historyPayload = newMessages.slice(-10).map(m => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch('/api/guardian/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: historyPayload,
          rolePersona: selectedPersona,
          model: selectedModel
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playCyberSound('beep', soundEnabled);
        const botMsg: ChatMessage = {
          id: `msg_b_${Date.now()}`,
          role: 'model',
          text: data.reply,
          timestamp: data.timestamp || new Date().toLocaleTimeString(),
          modelUsed: data.modelUsed,
          actionTrigger: data.actionTrigger
        };
        setMessages(prev => [...prev, botMsg]);
        speakMessage(data.reply);
      } else {
        playCyberSound('warning', soundEnabled);
        const fallbackMsg: ChatMessage = {
          id: `msg_err_${Date.now()}`,
          role: 'model',
          text: language === 'hi' 
            ? `⚠️ **[ऑटोनॉमस न्यूरल बैकअप]:** सर्वर लोड के कारण स्वचालित बैकअप मोड में उत्तर दिया गया। सिस्टम पूर्ण सुरक्षित है।`
            : `⚠️ **[Autonomous Neural Backup]:** Transient demand spike routed through local resilience shield. System is secure.`,
          timestamp: new Date().toLocaleTimeString(),
          modelUsed: 'guardian-neural-shield'
        };
        setMessages(prev => [...prev, fallbackMsg]);
      }
    } catch (err: any) {
      playCyberSound('warning', soundEnabled);
      const errorMsg: ChatMessage = {
        id: `msg_net_err_${Date.now()}`,
        role: 'model',
        text: `⚠️ Telemetry link error: ${err.message}. Neural offline fallback engaged.`,
        timestamp: new Date().toLocaleTimeString(),
        modelUsed: 'offline-core'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    playCyberSound('click', soundEnabled);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    playCyberSound('click', soundEnabled);
    setMessages([
      {
        id: `msg_cleared_${Date.now()}`,
        role: 'model',
        text: language === 'hi'
          ? "🧹 **चैट मेमोरी रीसेट संपन्न:** नया संवाद सत्र प्रारंभ हुआ। आप जो चाहें पूछें।"
          : "🧹 **Chat Memory Flushed:** New tactical conversation session initialized. Ready for commands.",
        timestamp: new Date().toLocaleTimeString(),
        modelUsed: selectedModel
      }
    ]);
  };

  // Quick Action Handler for Action Buttons
  const handleTriggerAction = (action: string) => {
    playCyberSound('ascension', soundEnabled);
    if (action === 'EVOLVE') {
      onEvolveTrigger();
    } else if (action === 'AUDIT') {
      onExecuteAction('audit');
      onNavigateTab('powers');
    } else if (action === 'DOWNLOAD_APK') {
      window.location.href = '/api/guardian/download-apk';
    } else if (action === 'LOCKDOWN') {
      onExecuteAction('quarantine');
    }
  };

  const QUICK_PROMPTS = [
    { label: language === 'hi' ? '⚡ 1000x कोड विकास ट्रिगर करो' : '⚡ Trigger 1000x Core Evolution', prompt: 'Trigger autonomous code evolution and increase Guardian defense level by 1000x efficiency.' },
    { label: language === 'hi' ? '📱 Android APK कैसे इंस्टॉल करें?' : '📱 How to install APK on Android', prompt: 'How do I install the Digital Guardian standalone APK directly on Android phone?' },
    { label: language === 'hi' ? '🔍 डीप क्वांटम सुरक्षा ऑडिट करो' : '🔍 Deep Quantum Security Audit', prompt: 'Run a deep 6-vector security audit and check for any rootkit or AST vulnerabilities.' },
    { label: language === 'hi' ? '🔐 AES-256 मेमोरी एन्क्रिप्शन' : '🔐 Explain AES-256 Memory Obfuscation', prompt: 'Explain how Digital Guardian obfuscates memory states using AES-256 and SHA-256 tamper signatures.' },
    { label: language === 'hi' ? '🚨 ज़ीरो-ट्रस्ट लॉकडाउन लागू करो' : '🚨 Enforce Zero-Trust Lockdown', prompt: 'Enforce immediate zero-trust quarantine and seal memory against external intrusions.' }
  ];

  return (
    <div className="flex flex-col h-[750px] rounded-2xl border border-emerald-500/30 bg-slate-950/90 backdrop-blur-xl shadow-2xl overflow-hidden font-mono">
      {/* Top HUD Bar */}
      <div className="p-4 border-b border-emerald-950/60 bg-gradient-to-r from-slate-900/90 via-slate-950/90 to-slate-900/90 flex flex-wrap items-center justify-between gap-3">
        {/* Title & Live Pulse */}
        <div className="flex items-center gap-3">
          <div className="relative p-2 rounded-xl bg-emerald-950/80 border border-emerald-500/40 shadow-lg shadow-emerald-950">
            <Bot className="w-5 h-5 text-emerald-400 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold font-cyber tracking-wider text-slate-100 flex items-center gap-1.5">
                <span>GEMINI GUARDIAN AI</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  1000X PRO
                </span>
              </h2>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'hi' ? 'मल्टी-टर्न न्यूरल डिफेंस चैटबॉट' : 'Multi-Turn Autonomous Cyber Assistant'}
            </p>
          </div>
        </div>

        {/* Persona & Model Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Persona selector */}
          <div className="flex items-center bg-slate-900/90 rounded-lg border border-slate-800 p-0.5">
            <span className="px-2 text-[10px] text-slate-400 hidden sm:inline">Role:</span>
            {[
              { id: 'sentinel', label: 'Sentinel 🛡️' },
              { id: 'tactician', label: 'Tactician 🧠' },
              { id: 'analyst', label: 'Red-Team ⚔️' },
              { id: 'overmind', label: 'Overmind 🔮' }
            ].map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedPersona(p.id as any)}
                className={`px-2 py-1 rounded text-[11px] transition-all ${
                  selectedPersona === p.id
                    ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Model selector */}
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value as any)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] text-cyan-400 focus:outline-none focus:border-cyan-500/50"
          >
            <option value="gemini-3.8-flash">gemini-3.8-flash (General)</option>
            <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fastest)</option>
            <option value="gemini-4-argon">gemini-4-argon (Complex)</option>
          </select>

          {/* Voice readout toggle */}
          <button
            onClick={() => setTtsEnabled(!ttsEnabled)}
            className={`p-1.5 rounded-lg border transition-colors ${
              ttsEnabled ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title={ttsEnabled ? "Disable Cyber Voice TTS" : "Enable Cyber Voice TTS"}
          >
            {ttsEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Reset chat */}
          <button
            onClick={handleClearChat}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
            title="Clear Chat History"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Command Prompt Chips */}
      <div className="px-4 py-2 bg-slate-900/40 border-b border-slate-800/40 flex items-center gap-2 overflow-x-auto text-[11px] no-scrollbar">
        <span className="text-slate-500 shrink-0 flex items-center gap-1">
          <Zap className="w-3 h-3 text-amber-400" />
          Quick:
        </span>
        {QUICK_PROMPTS.map((qp, i) => (
          <button
            key={i}
            onClick={() => handleSend(qp.prompt)}
            disabled={loading}
            className="px-2.5 py-1 rounded-full bg-slate-900/80 hover:bg-emerald-950/60 border border-slate-800 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-300 whitespace-nowrap transition-all shadow-sm shrink-0"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Messages Scrollable Thread */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'} animate-in fade-in duration-200`}
            >
              {/* Avatar Icon */}
              <div
                className={`p-2 rounded-xl shrink-0 border shadow-md ${
                  isUser
                    ? 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300'
                    : 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 border shadow-xl relative ${
                  isUser
                    ? 'bg-gradient-to-br from-cyan-950/40 to-slate-900/90 border-cyan-500/30 text-slate-100 rounded-tr-none'
                    : 'bg-gradient-to-br from-slate-900/90 to-emerald-950/20 border-emerald-500/30 text-slate-100 rounded-tl-none'
                }`}
              >
                {/* Meta header */}
                <div className="flex items-center justify-between gap-4 mb-2 pb-1.5 border-b border-slate-800/60 text-[10px] text-slate-400">
                  <div className="flex items-center gap-1.5 font-bold font-cyber uppercase tracking-wider">
                    {isUser ? (
                      <span className="text-cyan-400">OPERATOR</span>
                    ) : (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Shield className="w-3 h-3 text-emerald-400" />
                        GUARDIAN CORE ({msg.modelUsed || 'gemini'})
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span>{msg.timestamp}</span>
                    <button
                      onClick={() => handleCopy(msg.text, msg.id)}
                      className="text-slate-400 hover:text-slate-200"
                      title="Copy text"
                    >
                      {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                {/* Message Content */}
                <div className="text-xs leading-relaxed whitespace-pre-wrap space-y-2">
                  {msg.text}
                </div>

                {/* Interactive Action Trigger Button if present */}
                {msg.actionTrigger && (
                  <div className="mt-3 pt-3 border-t border-emerald-900/40 flex items-center gap-2">
                    {msg.actionTrigger === 'EVOLVE' && (
                      <button
                        onClick={() => handleTriggerAction('EVOLVE')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cyber font-bold text-xs bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-md shadow-emerald-500/20"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{language === 'hi' ? '⚡ अभी म्यूटेशन और विकास ट्रिगर करें' : '⚡ TRIGGER ASCENSION NOW'}</span>
                      </button>
                    )}

                    {msg.actionTrigger === 'DOWNLOAD_APK' && (
                      <a
                        href="/api/guardian/download-apk?v=5"
                        download="DigitalGuardian_v5_Pro_Signed.apk"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cyber font-bold text-xs bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 hover:from-cyan-400 hover:to-blue-400 shadow-md shadow-cyan-500/20"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{language === 'hi' ? '📥 Digital Guardian APK डाउनलोड करें (6.2 MB)' : '📥 DOWNLOAD DIGITAL GUARDIAN APK (6.2 MB)'}</span>
                      </a>
                    )}

                    {msg.actionTrigger === 'AUDIT' && (
                      <button
                        onClick={() => handleTriggerAction('AUDIT')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cyber font-bold text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:from-amber-400 hover:to-orange-400 shadow-md shadow-amber-500/20"
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>{language === 'hi' ? '🔍 डीप क्वांटम स्कैन चलाओ' : '🔍 RUN QUANTUM AUDIT'}</span>
                      </button>
                    )}

                    {msg.actionTrigger === 'LOCKDOWN' && (
                      <button
                        onClick={() => handleTriggerAction('LOCKDOWN')}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cyber font-bold text-xs bg-gradient-to-r from-rose-500 to-red-600 text-white hover:from-rose-400 hover:to-red-500 shadow-md shadow-rose-500/20"
                      >
                        <AlertOctagon className="w-3.5 h-3.5" />
                        <span>{language === 'hi' ? '🚨 ज़ीरो-ट्रस्ट सील लागू करें' : '🚨 ENFORCE ZERO-TRUST SEAL'}</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator */}
        {loading && (
          <div className="flex items-start gap-3 animate-pulse">
            <div className="p-2 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="rounded-2xl rounded-tl-none p-4 bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
              <Radio className="w-3.5 h-3.5 text-emerald-400 animate-ping" />
              <span>
                {language === 'hi' 
                  ? `गार्जियन AI (${selectedModel}) न्यूरल सिंथेसिस कर रहा है...` 
                  : `Guardian AI (${selectedModel}) is synthesizing cyber tactical intelligence...`}
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Composer Box */}
      <div className="p-3 sm:p-4 border-t border-emerald-950/60 bg-slate-900/90">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                language === 'hi'
                  ? "गार्जियन AI से कमांड या सवाल पूछें (उदा: '1000x evolve karo', 'apk download kaise karein')..."
                  : "Command Guardian AI (e.g., 'Evolve core 1000x', 'How to install APK', 'Run audit')..."
              }
              disabled={loading}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/30 transition-all font-mono"
            />
            <span className="absolute right-3 top-3 text-[10px] text-slate-600 font-cyber hidden sm:inline">
              GEMINI 1000X
            </span>
          </div>

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className={`p-3 rounded-xl border font-bold transition-all shrink-0 ${
              !input.trim() || loading
                ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-emerald-500 to-teal-500 border-emerald-400/50 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-lg shadow-emerald-500/20 active:scale-95'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
