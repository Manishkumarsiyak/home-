import React, { useState } from 'react';
import { 
  Database, 
  RotateCcw, 
  Clock, 
  FileCode, 
  CheckCircle2, 
  Download, 
  Layers, 
  Eye, 
  X, 
  Copy, 
  Check,
  ShieldCheck
} from 'lucide-react';
import { GuardianStatus, EvolutionRecord } from '../types';

interface BackupVaultProps {
  status: GuardianStatus | null;
  onRollback: (targetLevel: number) => Promise<void>;
  language: 'hi' | 'en' | 'dual';
}

export const BackupVault: React.FC<BackupVaultProps> = ({ status, onRollback, language }) => {
  const [selectedRecord, setSelectedRecord] = useState<EvolutionRecord | null>(null);
  const [rollingBackLevel, setRollingBackLevel] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  const history = status?.history || [];
  const currentLevel = status?.level || 1;
  const [rollbackConfirmLevel, setRollbackConfirmLevel] = useState<number | null>(null);

  const confirmAndRollback = async (lvl: number) => {
    setRollingBackLevel(lvl);
    setRollbackConfirmLevel(null);
    try {
      await onRollback(lvl);
    } finally {
      setRollingBackLevel(null);
    }
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-900/40 border border-teal-500/40 text-teal-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-cyber text-slate-100">
                {language === 'hi' ? 'बैकअप वॉल्ट व टाइम मशीन (Snapshot Vault)' : 'Snapshot Vault & Evolutionary Time Machine'}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {language === 'hi' 
                  ? 'हर विकास (Evolution) से ठीक पहले एक .bak स्नैपशॉट संग्रहीत होता है जिसे कभी भी रीस्टोर किया जा सकता है।'
                  : 'Automatic immutable timestamped snapshots created prior to each autonomous mutation cycle.'}
              </p>
            </div>
          </div>
          <div className="text-xs font-mono text-emerald-400 border border-emerald-900/50 bg-emerald-950/40 px-3 py-1 rounded-lg">
            {history.length} {language === 'hi' ? 'स्नैपशॉट्स' : 'Snapshots'}
          </div>
        </div>
      </div>

      {/* Snapshot History Grid */}
      <div className="space-y-3">
        {history.map((record) => {
          const isCurrent = record.level === currentLevel;
          return (
            <div
              key={record.id}
              className={`p-4 rounded-xl border transition-all ${
                isCurrent
                  ? 'border-emerald-500/50 bg-emerald-950/20 shadow-md shadow-emerald-950/50'
                  : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold font-cyber text-slate-100">
                      Level {record.level}: {record.title}
                    </span>
                    {isCurrent && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-bold">
                        ACTIVE LIVE
                      </span>
                    )}
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-slate-700 bg-slate-800 text-slate-300 uppercase">
                      {record.engineUsed}
                    </span>
                  </div>
                  <p className="text-xs font-mono text-slate-400">{record.description}</p>
                  <div className="flex items-center gap-3 text-[11px] font-mono text-slate-500 pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {new Date(record.timestamp).toLocaleString()}
                    </span>
                    <span>•</span>
                    <span>Snapshot: <strong className="text-slate-300">guardian_v{record.level}.py.bak</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-2 font-mono text-xs">
                  <button
                    onClick={() => setSelectedRecord(record)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-emerald-300 hover:border-emerald-500/40 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Code</span>
                  </button>

                  {!isCurrent && (
                    <button
                      onClick={() => setRollbackConfirmLevel(record.level)}
                      disabled={rollingBackLevel === record.level}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-600/40 bg-amber-950/40 text-amber-300 hover:bg-amber-900/50 transition-colors"
                    >
                      <RotateCcw className={`w-3.5 h-3.5 ${rollingBackLevel === record.level ? 'animate-spin' : ''}`} />
                      <span>{rollingBackLevel === record.level ? 'Reverting...' : 'Rollback'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Rollback In-UI Confirmation Modal */}
      {rollbackConfirmLevel !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-amber-500/50 bg-slate-950 p-6 shadow-2xl font-mono text-xs space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-cyber font-bold text-sm">
              <RotateCcw className="w-4 h-4" />
              <span>{language === 'hi' ? 'रोलबैक की पुष्टि करें' : 'Confirm Version Rollback'}</span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              {language === 'hi'
                ? `क्या आप वाकई गार्जियन को लेवल ${rollbackConfirmLevel} (guardian_v${rollbackConfirmLevel}.py.bak) पर वापस रीस्टोर करना चाहते हैं?`
                : `Are you sure you want to rollback Guardian code to Level ${rollbackConfirmLevel}?`}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setRollbackConfirmLevel(null)}
                className="px-4 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-slate-100"
              >
                {language === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                onClick={() => confirmAndRollback(rollbackConfirmLevel)}
                className="px-4 py-2 rounded-lg font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-md"
              >
                {language === 'hi' ? 'हाँ, रोलबैक करें' : 'Proceed Rollback'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Code Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-4xl max-h-[85vh] rounded-2xl border border-slate-800 bg-slate-950 flex flex-col shadow-2xl">
            <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between font-mono text-xs">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-slate-200">
                  Snapshot: guardian_v{selectedRecord.level}.py.bak
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(selectedRecord.code)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-emerald-300 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={() => setSelectedRecord(null)}
                  className="p-1 rounded text-slate-400 hover:text-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-4 overflow-y-auto flex-1">
              <pre className="font-mono text-xs text-slate-300 leading-relaxed">
                <code>{selectedRecord.code}</code>
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
