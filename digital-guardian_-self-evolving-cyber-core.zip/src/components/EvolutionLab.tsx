import React, { useState } from 'react';
import { 
  ShieldAlert, 
  CheckCircle, 
  XCircle, 
  Play, 
  Code2, 
  GitCompare, 
  Copy, 
  Check, 
  Sparkles,
  Lock,
  Layers,
  FileCode
} from 'lucide-react';
import { GuardianStatus } from '../types';

interface EvolutionLabProps {
  status: GuardianStatus | null;
  onTestSandbox: (code: string) => Promise<{ passed: boolean; message?: string; reason?: string }>;
  language: 'hi' | 'en' | 'dual';
}

export const EvolutionLab: React.FC<EvolutionLabProps> = ({
  status,
  onTestSandbox,
  language
}) => {
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ passed: boolean; message?: string; reason?: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'current' | 'diff'>('current');

  const currentCode = status?.currentCode || '';
  const currentLevel = status?.level || 1;
  const latestHistory = status?.history[0];
  const previousHistory = status?.history[1];

  const handleRunTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await onTestSandbox(currentCode);
      setTestResult(res);
    } finally {
      setTesting(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Sandbox Status Gates */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-base font-bold font-cyber text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-emerald-400" />
              <span>{language === 'hi' ? 'सुरक्षा सैंडबॉक्स व सिंटैक्स सत्यापन' : 'Evolution Safety Sandbox & Compiler Gates'}</span>
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-1">
              {language === 'hi' 
                ? 'नया कोड लागू होने से पहले सैंडबॉक्स में 4 स्तरों पर परखा जाता है।'
                : 'Every generated mutation must pass rigorous static safety filters and compilation checks before replacing live memory.'}
            </p>
          </div>

          <button
            onClick={handleRunTest}
            disabled={testing}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold border transition-all ${
              testing
                ? 'bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed'
                : 'bg-emerald-950/80 hover:bg-emerald-900/80 border-emerald-500/40 text-emerald-300 hover:border-emerald-400'
            }`}
          >
            <Play className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>{testing ? (language === 'hi' ? 'जाँच जारी है...' : 'AUDITING CODE...') : (language === 'hi' ? 'सैंडबॉक्स टेस्ट चलाएँ' : 'EXECUTE SANDBOX TEST')}</span>
          </button>
        </div>

        {/* 4 Safety Gates */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
          <div className="p-3.5 rounded-xl border border-emerald-900/40 bg-slate-950/70">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-400 text-[11px]">GATE 1: ZERO DAMAGE</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-bold text-slate-200">Forbidden Filter</div>
            <div className="text-[11px] text-slate-500 mt-1">
              Scans for rm -rf, rmtree('/'), os.remove('/')
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-emerald-900/40 bg-slate-950/70">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-400 text-[11px]">GATE 2: REPLICATION</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-bold text-slate-200">evolve_as_guardian</div>
            <div className="text-[11px] text-slate-500 mt-1">
              Guarantees presence of autonomous self-loop
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-emerald-900/40 bg-slate-950/70">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-400 text-[11px]">GATE 3: SYNTAX GATE</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-bold text-slate-200">python3 py_compile</div>
            <div className="text-[11px] text-slate-500 mt-1">
              Validates byte-code compilation in real-time
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-emerald-900/40 bg-slate-950/70">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-400 text-[11px]">GATE 4: BACKUP LOCK</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-bold text-slate-200">Snapshot Integrity</div>
            <div className="text-[11px] text-slate-500 mt-1">
              Creates .v{currentLevel}.bak snapshot before write
            </div>
          </div>
        </div>

        {/* Live Test Feedback Banner */}
        {testResult && (
          <div className={`mt-4 p-3.5 rounded-xl border font-mono text-xs flex items-center justify-between ${
            testResult.passed
              ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
          }`}>
            <div className="flex items-center gap-2">
              {testResult.passed ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
              <span>{testResult.passed ? testResult.message : testResult.reason}</span>
            </div>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-900">
              {testResult.passed ? 'PASSED ✅' : 'FAILED ❌'}
            </span>
          </div>
        )}
      </div>

      {/* Added Capabilities in This Evolution */}
      {latestHistory && (
        <div className="rounded-2xl border border-emerald-500/30 bg-slate-900/40 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-bold font-cyber text-slate-200 uppercase">
              {language === 'hi' ? `लेवल ${latestHistory.level} में सक्रिय साइबर सुरक्षा क्षमताएँ` : `Active Capabilities & Traits // Level ${latestHistory.level}`}
            </h4>
          </div>

          <div className="flex flex-wrap gap-2">
            {latestHistory.addedCapabilities.map((cap, i) => (
              <span
                key={i}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border border-emerald-500/30 bg-emerald-950/40 text-xs font-mono text-emerald-300"
              >
                <Lock className="w-3 h-3 text-emerald-400" />
                <span>{cap}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Code Inspector with Diff Toggle */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 font-mono text-xs">
            <FileCode className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-slate-200">guardian.py</span>
            <span className="text-slate-500">|</span>
            <span className="text-emerald-400">Generation {currentLevel}</span>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <div className="flex items-center rounded-lg border border-slate-700 bg-slate-800/80 p-0.5">
              <button
                onClick={() => setViewMode('current')}
                className={`px-3 py-1 rounded transition-all ${
                  viewMode === 'current' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code2 className="w-3.5 h-3.5 inline mr-1" />
                Source Code
              </button>
              <button
                onClick={() => setViewMode('diff')}
                className={`px-3 py-1 rounded transition-all ${
                  viewMode === 'diff' ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <GitCompare className="w-3.5 h-3.5 inline mr-1" />
                Mutation Log
              </button>
            </div>

            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-emerald-300 hover:border-emerald-500/40 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="p-4 overflow-x-auto max-h-[500px]">
          {viewMode === 'current' ? (
            <pre className="font-mono text-xs text-slate-300 leading-relaxed">
              <code>{currentCode}</code>
            </pre>
          ) : (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-3 rounded-xl border border-emerald-900/40 bg-emerald-950/20">
                <div className="text-emerald-400 font-bold mb-1">
                  Level {currentLevel} Mutation Summary:
                </div>
                <div className="text-slate-300">
                  {latestHistory?.description || 'Autonomous mutation applied.'}
                </div>
                <div className="text-slate-400 mt-2 text-[11px]">
                  Engine: <strong className="text-cyan-400 uppercase">{latestHistory?.engineUsed}</strong> | Timestamp: {latestHistory?.timestamp}
                </div>
              </div>

              {previousHistory && (
                <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/40">
                  <div className="text-slate-400 font-bold mb-1">
                    Previous Generation (Level {previousHistory.level}):
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    {previousHistory.description}
                  </div>
                </div>
              )}

              <div className="text-xs text-slate-400">
                <p className="font-semibold text-slate-300 mb-2">Key Evolutionary Injections:</p>
                <ul className="list-disc list-inside space-y-1 text-emerald-300/90">
                  <li>Safe exception catching for missing hardware and sensor libraries</li>
                  <li>Regex-based extraction of AI code blocks without shell injection vulnerabilities</li>
                  <li>Dual-API client with stateful rate-limit detection (Groq -&gt; Gemini)</li>
                  <li>Autonomous backup preservation into timestamped .bak files</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
