// Real Web Device Permissions & Sensor Manager

export interface PermissionStatusItem {
  id: string;
  name: string;
  nameHi: string;
  description: string;
  descriptionHi: string;
  state: 'granted' | 'denied' | 'prompt' | 'unsupported';
  icon: string;
}

export class DevicePowersManager {
  private static wakeLockSentinel: any = null;

  // 1. Check current status of standard permissions
  public static async queryPermissions(): Promise<Record<string, 'granted' | 'denied' | 'prompt' | 'unsupported'>> {
    const results: Record<string, 'granted' | 'denied' | 'prompt' | 'unsupported'> = {
      notifications: 'prompt',
      persistentStorage: 'prompt',
      wakeLock: 'prompt',
      battery: 'prompt',
      network: 'prompt'
    };

    // Notifications
    if (typeof window !== 'undefined' && 'Notification' in window) {
      results.notifications = Notification.permission as any;
    } else {
      results.notifications = 'unsupported';
    }

    // Persistent Storage
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persisted) {
      try {
        const isPersisted = await navigator.storage.persisted();
        results.persistentStorage = isPersisted ? 'granted' : 'prompt';
      } catch {
        results.persistentStorage = 'prompt';
      }
    } else {
      results.persistentStorage = 'unsupported';
    }

    // Wake Lock
    if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
      results.wakeLock = this.wakeLockSentinel ? 'granted' : 'prompt';
    } else {
      results.wakeLock = 'unsupported';
    }

    // Battery
    if (typeof navigator !== 'undefined' && 'getBattery' in (navigator as any)) {
      results.battery = 'granted';
    } else {
      results.battery = 'unsupported';
    }

    // Network
    if (typeof navigator !== 'undefined' && ('connection' in navigator || 'onLine' in navigator)) {
      results.network = 'granted';
    }

    return results;
  }

  // 2. Request Notification Permission
  public static async requestNotificationPermission(): Promise<boolean> {
    if (!('Notification' in window)) return false;
    try {
      const res = await Notification.requestPermission();
      if (res === 'granted') {
        new Notification("🛡️ Digital Guardian Online", {
          body: "स्वायत्त सुरक्षा शील्ड सक्रिय है। सिस्टम सुरक्षा निगरानी चालू।",
          icon: "/icon.svg"
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  // 3. Request Persistent Storage Exemption
  public static async requestPersistentStorage(): Promise<boolean> {
    if (navigator.storage && navigator.storage.persist) {
      try {
        const granted = await navigator.storage.persist();
        return granted;
      } catch {
        return false;
      }
    }
    return false;
  }

  // 4. Toggle Screen Wake Lock (Active Sentry Mode)
  public static async toggleWakeLock(enable: boolean): Promise<boolean> {
    if (!('wakeLock' in navigator)) return false;
    try {
      if (enable) {
        if (!this.wakeLockSentinel) {
          this.wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
          this.wakeLockSentinel.addEventListener('release', () => {
            this.wakeLockSentinel = null;
          });
        }
        return true;
      } else {
        if (this.wakeLockSentinel) {
          await this.wakeLockSentinel.release();
          this.wakeLockSentinel = null;
        }
        return false;
      }
    } catch {
      return false;
    }
  }

  public static isWakeLockActive(): boolean {
    return this.wakeLockSentinel !== null;
  }

  // 5. Send Native Notification
  public static sendAlert(title: string, body: string) {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: "/icon.svg"
        });
      } catch {}
    }
  }

  // 6. Real Sensor Readings
  public static async getRealHardwareMetrics() {
    const metrics: {
      batteryPct?: number;
      charging?: boolean;
      networkType?: string;
      downlinkMbps?: number;
      rttMs?: number;
      ramGb?: number;
      cpuCores?: number;
      storageEstimateMb?: number;
      storageQuotaMb?: number;
    } = {};

    if (typeof navigator !== 'undefined') {
      if ('hardwareConcurrency' in navigator) {
        metrics.cpuCores = navigator.hardwareConcurrency;
      }
      if ('deviceMemory' in (navigator as any)) {
        metrics.ramGb = (navigator as any).deviceMemory;
      }
      if ('connection' in (navigator as any)) {
        const conn = (navigator as any).connection;
        metrics.networkType = conn.effectiveType || conn.type || 'wifi';
        metrics.downlinkMbps = conn.downlink;
        metrics.rttMs = conn.rtt;
      }
      if ('getBattery' in (navigator as any)) {
        try {
          const bat = await (navigator as any).getBattery();
          metrics.batteryPct = Math.round(bat.level * 100);
          metrics.charging = bat.charging;
        } catch {}
      }
      if (navigator.storage && navigator.storage.estimate) {
        try {
          const estimate = await navigator.storage.estimate();
          metrics.storageEstimateMb = Math.round((estimate.usage || 0) / (1024 * 1024));
          metrics.storageQuotaMb = Math.round((estimate.quota || 0) / (1024 * 1024));
        } catch {}
      }
    }

    return metrics;
  }
}
