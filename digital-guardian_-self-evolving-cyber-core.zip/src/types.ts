export interface HealthTelemetry {
  storage_free_gb: number;
  platform: string;
  battery_level?: number;
  integrity_hash: string;
}

export interface EvolutionRecord {
  id: string;
  level: number;
  timestamp: string;
  engineUsed: 'groq' | 'gemini' | 'hybrid';
  title: string;
  description: string;
  addedCapabilities: string[];
  codeSnippetDiff: string;
  code: string;
  health: HealthTelemetry;
}

export interface TerminalLog {
  timestamp: string;
  type: 'system' | 'info' | 'success' | 'warning' | 'error' | 'guardian';
  text: string;
}

export interface GuardianStatus {
  level: number;
  rank: string;
  resilienceScore: number;
  activeDefenseShield: boolean;
  stealthMode: boolean;
  autoBackupEnabled: boolean;
  totalMutations: number;
  uptimeSeconds: number;
  currentCode: string;
  historyCount: number;
  history: EvolutionRecord[];
  terminalLogs: TerminalLog[];
  systemTelemetry: {
    platform: string;
    freeMemGb: number;
    cpuCount: number;
    loadAvg: number;
    integrityHash: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  modelUsed?: string;
  actionTrigger?: 'EVOLVE' | 'AUDIT' | 'DOWNLOAD_APK' | 'LOCKDOWN' | 'ROLLBACK' | null;
}

export interface ThreatNode {
  id: string;
  name: string;
  lat: number;
  lng: number;
  status: string;
  pings: number;
  attacksBlocked: number;
  latencyMs: number;
}

export interface CipherResult {
  action: 'encrypt' | 'decrypt';
  ciphertext?: string;
  plaintext?: string;
  iv?: string;
  authTag?: string;
  algorithm: string;
  integrityHash?: string;
  executionTimeMs?: number;
}
