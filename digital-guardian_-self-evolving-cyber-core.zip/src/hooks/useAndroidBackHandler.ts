import { useEffect, useRef } from 'react';

interface AndroidBackHandlerOptions {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onConfirmExit?: () => void;
}

/**
 * Handles Android Hardware Back Button and Back Swiping Gestures in Android WebView / PWA.
 * Prevents accidental app exit when browsing tabs.
 */
export function useAndroidBackHandler({
  activeTab,
  setActiveTab,
  onConfirmExit
}: AndroidBackHandlerOptions) {
  const isNavigatingRef = useRef(false);

  useEffect(() => {
    // Push current tab state to history
    window.history.pushState({ tab: activeTab }, '', `#${activeTab}`);

    const handlePopState = (event: PopStateEvent) => {
      // If back pressed and we are not on home tab
      if (activeTab !== 'apk' && activeTab !== 'deck') {
        event.preventDefault?.();
        setActiveTab('apk');
        // Push state again so next back doesn't close app unexpectedly
        window.history.pushState({ tab: 'apk' }, '', '#apk');
      } else {
        // We are on home tab, trigger exit confirmation if available
        if (onConfirmExit) {
          window.history.pushState({ tab: activeTab }, '', `#${activeTab}`);
          onConfirmExit();
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [activeTab, setActiveTab, onConfirmExit]);
}
