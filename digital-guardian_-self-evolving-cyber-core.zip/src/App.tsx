import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { CommandDeck } from './components/CommandDeck';
import { ThreatRadar } from './components/ThreatRadar';
import { EvolutionLab } from './components/EvolutionLab';
import { CyberTerminal } from './components/CyberTerminal';
import { PythonCodeViewer } from './components/PythonCodeViewer';
import { BackupVault } from './components/BackupVault';
import { PermissionsDeck } from './components/PermissionsDeck';
import { GeminiChatbot } from './components/GeminiChatbot';
import { ApkDownloadHub } from './components/ApkDownloadHub';
import { QuantumNeuralMatrix } from './components/QuantumNeuralMatrix';
import { AndroidOfflineShield } from './components/AndroidOfflineShield';
import { AndroidOptimizationModal } from './components/AndroidOptimizationModal';
import { useAndroidBackHandler } from './hooks/useAndroidBackHandler';
import { GuardianStatus } from './types';
import { playCyberSound } from './utils/audio';
import { AlertTriangle, CheckCircle2, RotateCcw, X, Info, Smartphone } from 'lucide-react';

export default function App() {
  const [status, setStatus] = useState<GuardianStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEvolving, setIsEvolving] = useState(false);
  const [activeTab, setActiveTab] = useState('apk');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [language, setLanguage] = useState<'hi' | 'en' | 'dual'>('hi');
  const [ascendedModal, setAscendedModal] = useState<{ level: number; rank: string; engine: string } | null>(null);
  
  // Android Specific UX States
  const [confirmExitOpen, setConfirmExitOpen] = useState(false);
  const [showAndroidOptModal, setShowAndroidOptModal] = useState(false);

  // Android Hardware Back Button & Gesture Handler
  useAndroidBackHandler({
    activeTab,
    setActiveTab,
    onConfirmExit: () => setConfirmExitOpen(true)
  });

  // In-UI Toast & Confirm state (avoids window.alert/window.confirm)
  const [uiToast, setUiToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  // Auto-Pilot Autonomous Evolution Mode
  const [autoPilot, setAutoPilot] = useState(false);
  const autoPilotTimerRef = useRef<any>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setUiToast({ message, type });
    setTimeout(() => {
      setUiToast(prev => (prev?.message === message ? null : prev));
    }, 4500);
  };

  // Fetch status from server
  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/guardian/status');
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
      }
    } catch (err) {
      console.error('Failed to fetch guardian status:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    // Poll telemetry every 15 seconds
    const interval = setInterval(fetchStatus, 15000);
    return () => clearInterval(interval);
  }, []);

  // Trigger Evolution Cycle
  const handleTriggerEvolve = async (directive = '') => {
    if (isEvolving) return;
    setIsEvolving(true);
    playCyberSound('scan', soundEnabled);

    try {
      const res = await fetch('/api/guardian/evolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ directive })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playCyberSound('ascension', soundEnabled);
        
        // Trigger celebratory cyber confetti
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#10b981', '#06b6d4', '#14b8a6', '#f59e0b']
          });
        } catch {}

        setAscendedModal({
          level: data.level,
          rank: data.rank,
          engine: data.engineUsed
        });

        showToast(`✅ Ascension Complete: Evolved to Level ${data.level}!`, 'success');
        await fetchStatus();
      } else {
        playCyberSound('warning', soundEnabled);
        showToast(`Evolution Warning: ${data.error || 'Retry with alternate directive'}`, 'error');
        await fetchStatus();
      }
    } catch (err: any) {
      playCyberSound('warning', soundEnabled);
      showToast(`Network telemetry error: ${err.message}`, 'error');
    } finally {
      setIsEvolving(false);
    }
  };

  // Auto-Pilot Effect
  useEffect(() => {
    if (autoPilot) {
      showToast(language === 'hi' ? 'ऑटोनॉमस ऑटो-पायलट सक्रिय (Autonomous Evolution Loop Armed)' : 'Auto-Pilot Engaged: Scanning & Self-Optimizing...', 'info');
      autoPilotTimerRef.current = setInterval(() => {
        if (!isEvolving) {
          handleTriggerEvolve("Autonomous continuous survival optimization");
        }
      }, 55000);
    } else {
      if (autoPilotTimerRef.current) clearInterval(autoPilotTimerRef.current);
    }
    return () => {
      if (autoPilotTimerRef.current) clearInterval(autoPilotTimerRef.current);
    };
  }, [autoPilot]);

  // Run Sandbox Test
  const handleTestSandbox = async (code: string) => {
    playCyberSound('beep', soundEnabled);
    try {
      const res = await fetch('/api/guardian/test-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      const data = await res.json();
      if (data.passed) {
        playCyberSound('click', soundEnabled);
        showToast("Sandbox Gate 1-4: All Safety Filters Passed ✅", "success");
      } else {
        playCyberSound('warning', soundEnabled);
        showToast(`Sandbox Violation: ${data.reason}`, "error");
      }
      return data;
    } catch (err: any) {
      playCyberSound('warning', soundEnabled);
      showToast(`Sandbox check error: ${err.message}`, "error");
      return { passed: false, reason: err.message };
    }
  };

  // Rollback to older version
  const handleRollback = async (targetLevel: number) => {
    playCyberSound('click', soundEnabled);
    try {
      const res = await fetch('/api/guardian/rollback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetLevel })
      });
      if (res.ok) {
        showToast(`Restored to Level ${targetLevel} snapshot`, "success");
        await fetchStatus();
      }
    } catch (err) {
      console.error('Failed to rollback:', err);
      showToast("Rollback error", "error");
    }
  };

  // Execute Core Reset
  const executeReset = async () => {
    setConfirmResetOpen(false);
    playCyberSound('warning', soundEnabled);
    try {
      const res = await fetch('/api/guardian/reset', { method: 'POST' });
      if (res.ok) {
        showToast(language === 'hi' ? "गार्जियन कोर लेवल 1 पर रीसेट हो गया" : "Core reset to Genesis Level 1", "info");
        await fetchStatus();
      }
    } catch (err) {
      console.error('Failed to reset:', err);
    }
  };

  // Handle Command Line input in CyberTerminal
  const handleTerminalCommand = (rawCmd: string) => {
    const cmd = rawCmd.trim().toLowerCase();
    playCyberSound('beep', soundEnabled);

    if (cmd === 'help') {
      setStatus(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          terminalLogs: [
            ...prev.terminalLogs,
            { timestamp: new Date().toLocaleTimeString(), type: 'info', text: "Available commands: 'status', 'evolve', 'health', 'radar', 'autopilot', 'sandbox', 'clear', 'hindi', 'eng'" }
          ]
        };
      });
    } else if (cmd === 'status') {
      setStatus(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          terminalLogs: [
            ...prev.terminalLogs,
            { timestamp: new Date().toLocaleTimeString(), type: 'success', text: `Guardian Level: ${prev.level} | Rank: ${prev.rank} | Resilience: ${prev.resilienceScore}%` }
          ]
        };
      });
    } else if (cmd === 'health') {
      setStatus(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          terminalLogs: [
            ...prev.terminalLogs,
            { timestamp: new Date().toLocaleTimeString(), type: 'info', text: `Storage: ${prev.history[0]?.health?.storage_free_gb || 36.2} GB | Battery: ${prev.history[0]?.health?.battery_level || 92}% | Platform: ${prev.systemTelemetry?.platform || 'linux'}` }
          ]
        };
      });
    } else if (cmd === 'evolve') {
      handleTriggerEvolve();
    } else if (cmd === 'radar') {
      setActiveTab('radar');
    } else if (cmd === 'autopilot') {
      setAutoPilot(prev => !prev);
    } else if (cmd === 'clear') {
      setStatus(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          terminalLogs: [
            { timestamp: new Date().toLocaleTimeString(), type: 'system', text: "[Terminal]: Logs cleared by operator." }
          ]
        };
      });
    } else if (cmd === 'hindi') {
      setLanguage('hi');
    } else if (cmd === 'eng') {
      setLanguage('en');
    } else {
      setStatus(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          terminalLogs: [
            ...prev.terminalLogs,
            { timestamp: new Date().toLocaleTimeString(), type: 'warning', text: `Unknown command: '${rawCmd}'. Type 'help' for command list.` }
          ]
        };
      });
    }
  };

  const handleClearLogs = () => {
    setStatus(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        terminalLogs: []
      };
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center font-mono text-emerald-400 gap-3">
        <div className="relative flex h-8 w-8">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-8 w-8 bg-emerald-500"></span>
        </div>
        <div className="text-sm tracking-widest font-cyber">INITIALIZING GUARDIAN PRO CORE...</div>
      </div>
    );
  }

  // Defense Action Handler
  const handleDefenseAction = async (action: string) => {
    playCyberSound('click', soundEnabled);
    try {
      const res = await fetch('/api/guardian/defense-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      const data = await res.json();
      showToast(data.message || `Action ${action} executed`, 'success');
      await fetchStatus();
    } catch (err: any) {
      showToast(`Defense action error: ${err.message}`, 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 cyber-grid selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Header */}
      <Header
        status={status}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isEvolving={isEvolving}
        onTriggerEvolve={() => handleTriggerEvolve()}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        language={language}
        setLanguage={setLanguage}
      />

      {/* Main Content Viewport */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'chat' && (
          <GeminiChatbot
            status={status}
            language={language}
            soundEnabled={soundEnabled}
            onExecuteAction={(action) => handleDefenseAction(action)}
            onEvolveTrigger={() => handleTriggerEvolve("Triggered via Gemini Cyber Assistant")}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'apk' && (
          <ApkDownloadHub
            language={language}
            soundEnabled={soundEnabled}
          />
        )}

        {activeTab === 'quantum' && (
          <QuantumNeuralMatrix
            language={language}
            soundEnabled={soundEnabled}
            level={status?.level || 1}
          />
        )}

        {activeTab === 'deck' && (
          <CommandDeck
            status={status}
            isEvolving={isEvolving}
            onEvolveWithDirective={(directive) => handleTriggerEvolve(directive)}
            onReset={() => setConfirmResetOpen(true)}
            language={language}
          />
        )}

        {activeTab === 'radar' && (
          <ThreatRadar
            language={language}
            soundEnabled={soundEnabled}
            onThreatIntercepted={(msg) => {
              setStatus(prev => {
                if (!prev) return prev;
                return {
                  ...prev,
                  terminalLogs: [
                    ...prev.terminalLogs,
                    { timestamp: new Date().toLocaleTimeString(), type: 'success', text: msg }
                  ]
                };
              });
              showToast(msg, 'success');
            }}
          />
        )}

        {activeTab === 'powers' && (
          <PermissionsDeck
            language={language}
            soundEnabled={soundEnabled}
            onAuditCompleted={(score) => {
              setStatus(prev => prev ? { ...prev, resilienceScore: Math.max(prev.resilienceScore, score) } : prev);
              showToast(`Security Audit Complete: Resilience Rating ${score}%`, 'success');
            }}
          />
        )}

        {activeTab === 'lab' && (
          <EvolutionLab
            status={status}
            onTestSandbox={handleTestSandbox}
            language={language}
          />
        )}

        {activeTab === 'terminal' && (
          <CyberTerminal
            logs={status?.terminalLogs || []}
            status={status}
            onCommand={handleTerminalCommand}
            onClear={handleClearLogs}
            language={language}
          />
        )}

        {activeTab === 'python' && (
          <PythonCodeViewer
            status={status}
            language={language}
          />
        )}

        {activeTab === 'vault' && (
          <BackupVault
            status={status}
            onRollback={handleRollback}
            language={language}
          />
        )}
      </main>

      {/* In-UI Notification Toast (Replaces window.alert) */}
      {uiToast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-xl border font-mono text-xs shadow-2xl backdrop-blur-md animate-in slide-in-from-bottom-5">
          <div className={`p-1.5 rounded-lg ${
            uiToast.type === 'success' ? 'bg-emerald-950 border border-emerald-500 text-emerald-400' :
            uiToast.type === 'error' ? 'bg-rose-950 border border-rose-500 text-rose-400' :
            'bg-slate-900 border border-slate-700 text-cyan-400'
          }`}>
            {uiToast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> :
             uiToast.type === 'error' ? <AlertTriangle className="w-4 h-4" /> :
             <Info className="w-4 h-4" />}
          </div>
          <span className="text-slate-100 font-medium">{uiToast.message}</span>
          <button onClick={() => setUiToast(null)} className="text-slate-400 hover:text-slate-100 ml-2">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* In-UI Reset Confirmation Modal (Replaces window.confirm) */}
      {confirmResetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-rose-500/50 bg-slate-950 p-6 shadow-2xl font-mono text-xs space-y-4">
            <div className="flex items-center gap-2 text-rose-400 font-cyber font-bold text-sm">
              <RotateCcw className="w-4 h-4" />
              <span>{language === 'hi' ? 'कोर रीसेट की पुष्टि करें' : 'Confirm Guardian Core Reset'}</span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              {language === 'hi'
                ? 'क्या आप वाकई गार्जियन को लेवल 1 (Genesis Seed) पर वापस रीसेट करना चाहते हैं? इससे सभी वर्तमान विकास पूर्ववत हो जाएंगे।'
                : 'Are you sure you want to reset the Guardian back to Level 1 Genesis Seed? This will roll back all dynamic mutations.'}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmResetOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-slate-100"
              >
                {language === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                onClick={executeReset}
                className="px-4 py-2 rounded-lg font-bold bg-rose-600 text-white hover:bg-rose-500 shadow-md"
              >
                {language === 'hi' ? 'हाँ, रीसेट करें' : 'Reset Core'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Ascension Celebration Modal */}
      {ascendedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl border border-emerald-500/60 bg-gradient-to-b from-slate-900 to-slate-950 p-6 shadow-2xl shadow-emerald-500/20 text-center font-mono">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-950/80 border border-emerald-400/50 flex items-center justify-center text-3xl shadow-lg shadow-emerald-950 animate-pulse">
              🛡️
            </div>

            <div className="text-xs font-bold font-cyber text-emerald-400 tracking-widest uppercase mb-1">
              --- ✅ विकास सफल (ASCENDED) ---
            </div>
            
            <h3 className="text-2xl font-bold font-cyber text-slate-100 mb-2">
              Ascended to Level {ascendedModal.level}!
            </h3>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              {language === 'hi'
                ? `डिजिटल गार्जियन ने नया विकास सफलतापूर्वक पूरा किया और '${ascendedModal.rank}' में उन्नत हो गया है।`
                : `Digital Guardian has completed the mutation cycle using ${ascendedModal.engine.toUpperCase()} and ascended to ${ascendedModal.rank}.`}
            </p>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-left text-xs mb-5 space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Backup Created:</span>
                <span className="text-emerald-400 font-bold">guardian.v{ascendedModal.level - 1}.bak</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>AI Engine:</span>
                <span className="text-cyan-400 uppercase font-bold">{ascendedModal.engine}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Sandbox Verification:</span>
                <span className="text-emerald-400 font-bold">PASSED ✅</span>
              </div>
            </div>

            <button
              onClick={() => {
                setAscendedModal(null);
                setActiveTab('lab');
              }}
              className="w-full py-2.5 rounded-xl font-bold font-cyber text-xs tracking-wider bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-lg shadow-emerald-500/20 transition-all"
            >
              INSPECT EVOLVED CODE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
